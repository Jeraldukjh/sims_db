<?php
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_id = $_POST['item_id'];
    $return_condition = $_POST['return_condition'];
    $return_notes = trim($_POST['return_notes']);
    $student_id = $_SESSION['student_id'];

    try {
        // Check if the item is actually borrowed by this student
        $check_stmt = $pdo->prepare("SELECT * FROM borrow_requests WHERE item_id = ? AND student_id = ? AND status = 'approved' AND return_status IS NULL");
        $check_stmt->execute([$item_id, $student_id]);
        $borrow_request = $check_stmt->fetch(PDO::FETCH_ASSOC);

        if (!$borrow_request) {
            $_SESSION['error'] = "This item is not currently borrowed by you.";
            header("Location: inventory.php");
            exit();
        }

        // Update borrow request with return information
        $stmt = $pdo->prepare("UPDATE borrow_requests SET 
            return_status = 'returned',
            return_condition = ?,
            return_notes = ?,
            actual_return_date = NOW()
            WHERE id = ?");
        
        if ($stmt->execute([$return_condition, $return_notes, $borrow_request['id']])) {
            // Update inventory quantity
            $update_inventory = $pdo->prepare("UPDATE inventory_items SET quantity = quantity + 1 WHERE id = ?");
            $update_inventory->execute([$item_id]);

            // Add notification for admin
            $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, student_id, message, is_read, created_at) VALUES (0, ?, ?, 0, NOW())");
            $notif_message = "Item ID: " . $item_id . " has been returned by student ID: " . $student_id;
            $notif_stmt->execute([$student_id, $notif_message]);

            $_SESSION['success'] = "Item returned successfully!";
        } else {
            $_SESSION['error'] = "Failed to process return.";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "An error occurred. Please try again.";
    }

    header("Location: inventory.php");
    exit();
} else {
    header("Location: inventory.php");
    exit();
}
?> 