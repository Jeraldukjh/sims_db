<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/api_error_response.php';
header('Content-Type: application/json');

// Get the token from the Authorization header
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;

if (!$token) {
    api_error_response('No token provided', 401, ['endpoint' => $_SERVER['PHP_SELF']]);
}

try {
    $stmt = $pdo->prepare("SELECT id, is_admin FROM users WHERE token = :token AND is_admin = 1");
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        api_error_response('Invalid or expired token', 401, ['endpoint' => $_SERVER['PHP_SELF']]);
    }

    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['product_name']) || empty($data['stock'])) {
        api_error_response('Missing product_name or stock', 400, array_merge($data, ['endpoint' => $_SERVER['PHP_SELF']]));
    }

    // Insert new product
    $product_name = $data['product_name'];
    $stock = $data['stock'];
    $category = $data['category'];
    $image_url = isset($data['image_url']) ? $data['image_url'] : null;
    $stmt = $pdo->prepare("
        INSERT INTO products (product_name, stock, category, image_url) 
        VALUES (:product_name, :stock, :category, :image_url)
    ");
    $stmt->bindParam(':product_name', $product_name);
    $stmt->bindParam(':stock', $stock);
    $stmt->bindParam(':category', $category);
    $stmt->bindParam(':image_url', $image_url);
    $stmt->execute();
    
    echo json_encode([
        "status" => "success",
        "message" => "Product created successfully",
        "product_id" => $pdo->lastInsertId()
    ]);
    
} catch (PDOException $e) {
    api_error_response('Database error: ' . $e->getMessage(), 500, array_merge($data ?? [], ['endpoint' => $_SERVER['PHP_SELF']]));
}
?> 