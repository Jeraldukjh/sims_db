<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/api_error_response.php';
header('Content-Type: application/json');

// Get the token from the Authorization header
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;

if (!$token) {
    api_error_response('No token provided', 401, ['endpoint' => $_SERVER['PHP_SELF']]);
}

// Verify admin token
try {
    $stmt = $pdo->prepare("SELECT id, is_admin FROM users WHERE token = :token AND is_admin = 1");
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        api_error_response('Invalid or expired token', 401, ['endpoint' => $_SERVER['PHP_SELF']]);
    }

    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['student_id']) || !isset($data['password']) || !isset($data['name']) || !isset($data['email'])) {
        api_error_response('Missing required fields', 400, array_merge($data, ['endpoint' => $_SERVER['PHP_SELF']]));
    }

    // Hash the password
    $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);
    
    // Insert new user
    $student_id = $data['student_id'];
    $name = $data['name'];
    $email = $data['email'];
    $is_admin = isset($data['is_admin']) ? $data['is_admin'] : 0;
    $role = isset($data['role']) ? $data['role'] : 'user';
    $profile_pic = isset($data['profile_pic']) ? $data['profile_pic'] : 'default.jpg';
    $approved = isset($data['approved']) ? $data['approved'] : 0;

    $stmt = $pdo->prepare("
        INSERT INTO users (student_id, password, name, email, is_admin, role, profile_pic, approved) 
        VALUES (:student_id, :password, :name, :email, :is_admin, :role, :profile_pic, :approved)
    ");
    
    $stmt->bindValue(':student_id', $student_id);
    $stmt->bindValue(':password', $hashed_password);
    $stmt->bindValue(':name', $name);
    $stmt->bindValue(':email', $email);
    $stmt->bindValue(':is_admin', $is_admin);
    $stmt->bindValue(':role', $role);
    $stmt->bindValue(':profile_pic', $profile_pic);
    $stmt->bindValue(':approved', $approved);
    
    $stmt->execute();
    
    echo json_encode([
        "status" => "success",
        "message" => "User created successfully",
        "user_id" => $pdo->lastInsertId()
    ]);
    
} catch (PDOException $e) {
    api_error_response('Database error: ' . $e->getMessage(), 500, array_merge($data ?? [], ['endpoint' => $_SERVER['PHP_SELF']]));
}
?> 