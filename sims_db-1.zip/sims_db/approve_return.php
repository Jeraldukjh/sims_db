<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['is_admin'])) {
    die("Unauthorized access");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_id'])) {
    try {
        $requestId = $_POST['request_id'];
        $studentName = $_POST['student_name'];
        $productName = $_POST['product_name'];

        // Get student_id and product_id from the request
        $stmt = $pdo->prepare("SELECT student_id, product_id FROM return_requests WHERE request_id = ?");
        $stmt->execute([$requestId]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);
        $studentId = $request['student_id'];
        $productId = $request['product_id'];

        if ($studentId && $productId) {
            // Update the request status
            $stmt = $pdo->prepare("UPDATE return_requests SET status = 'approved' WHERE request_id = ?");
            $stmt->execute([$requestId]);

            // Update the borrow_requests status to returned
            $stmt = $pdo->prepare("UPDATE borrow_requests SET status = 'returned' WHERE student_id = ? AND product_id = ? AND status = 'approved'");
            $stmt->execute([$studentId, $productId]);

            // Send notification
            $message = "Your return request for {$productName} has been approved.";
            $stmt = $pdo->prepare("INSERT INTO notifications (user_id, student_id, message, is_read, created_at) VALUES (?, ?, ?, 0, NOW())");
            $stmt->execute([0, $studentId, $message]);

            echo "Return request approved successfully!";
        } else {
            echo "Error: Student or Product ID not found.";
        }
    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
    }
} else {
    echo "Invalid request.";
}
?> 