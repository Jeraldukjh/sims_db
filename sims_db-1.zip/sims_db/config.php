<?php

$base_url = 'http://172.17.254.8/sims_db'; 

$db_host = 'localhost';
$db_name = 'sims_db';
$db_user = 'root';
$db_pass = '';

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

?>