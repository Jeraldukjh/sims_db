<?php
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_id = $_POST['item_id'];
    $borrow_date = $_POST['borrow_date'];
    $return_date = $_POST['return_date'];
    $purpose = trim($_POST['purpose']);
    $student_id = $_SESSION['student_id'];

    // Validate dates
    if (strtotime($borrow_date) > strtotime($return_date)) {
        $_SESSION['error'] = "Return date must be after borrow date.";
        header("Location: inventory.php");
        exit();
    }

    try {
        // Check if item is available
        $check_stmt = $pdo->prepare("SELECT quantity FROM inventory_items WHERE id = ?");
        $check_stmt->execute([$item_id]);
        $item = $check_stmt->fetch(PDO::FETCH_ASSOC);

        if ($item['quantity'] <= 0) {
            $_SESSION['error'] = "Sorry, this item is currently not available.";
            header("Location: inventory.php");
            exit();
        }

        // Insert borrow request
        $stmt = $pdo->prepare("INSERT INTO borrow_requests (item_id, student_id, borrow_date, return_date, purpose, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', NOW())");
        
        if ($stmt->execute([$item_id, $student_id, $borrow_date, $return_date, $purpose])) {
            // Add notification for admin
            $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, student_id, message, is_read, created_at) VALUES (0, ?, ?, 0, NOW())");
            $notif_message = "A new borrow request has been submitted for item ID: " . $item_id;
            $notif_stmt->execute([$student_id, $notif_message]);

            $_SESSION['success'] = "Borrow request submitted successfully! Waiting for admin approval.";
        } else {
            $_SESSION['error'] = "Failed to submit borrow request.";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "An error occurred. Please try again.";
    }

    header("Location: inventory.php");
    exit();
} else {
    header("Location: inventory.php");
    exit();
}
?> 