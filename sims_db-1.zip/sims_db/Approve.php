<?php
require_once 'db.php';
session_start(); // Ensure the session is started

$error = '';
$success = '';

// Handle password reset
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reset_password'])) {
    $user_id = trim($_POST["user_id"]);
    $new_password = trim($_POST["new_password"]);
    
    try {
        $stmt = $pdo->prepare("UPDATE users SET password = :password WHERE id = :user_id");
        $stmt->bindValue(':password', password_hash($new_password, PASSWORD_DEFAULT), PDO::PARAM_STR);
        $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            $success = "Password reset successfully!";
        } else {
            throw new Exception("Error: Could not reset the password.");
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Handle admin role toggle
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['toggle_admin'])) {
    $user_id = trim($_POST["user_id"]);
    $is_admin = trim($_POST["is_admin"]) == '1' ? 0 : 1; // Toggle between 0 and 1
    
    try {
        $stmt = $pdo->prepare("UPDATE users SET is_admin = :is_admin WHERE id = :user_id");
        $stmt->bindValue(':is_admin', $is_admin, PDO::PARAM_INT);
        $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        if ($stmt->execute()) {
            $success = $is_admin ? "User is now an admin!" : "User is no longer an admin!";
        } else {
            throw new Exception("Error: Could not update user role.");
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Handle new student addition
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_student'])) {
    $name = trim($_POST["name"]);
    $student_id = trim($_POST["student_id"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    try {
        // Check if student ID already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE student_id = :student_id");
        $stmt->bindValue(':student_id', $student_id, PDO::PARAM_STR);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            throw new Exception("Error: Student ID already exists.");
        }

        // Add new student
        $stmt = $pdo->prepare("INSERT INTO users (name, student_id, email, password, approved) VALUES (:name, :student_id, :email, :password, 1)");
        $stmt->bindValue(':name', $name, PDO::PARAM_STR);
        $stmt->bindValue(':student_id', $student_id, PDO::PARAM_STR);
        $stmt->bindValue(':email', $email, PDO::PARAM_STR);
        $stmt->bindValue(':password', password_hash($password, PASSWORD_DEFAULT), PDO::PARAM_STR);
        
        if ($stmt->execute()) {
            $success = "Student added successfully!";
        } else {
            throw new Exception("Error: Could not add the student.");
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Handle user approval
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['approve_user'])) {
    $user_id = trim($_POST["user_id"]);
    try {
        $stmt = $pdo->prepare("UPDATE users SET approved = 1 WHERE id = :user_id");
        $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        if ($stmt->execute()) {
            $success = "User approved successfully!";
        } else {
            throw new Exception("Error: Could not approve the user.");
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Fetch all users from the users table
$stmt = $pdo->prepare("SELECT id, name, student_id, email, approved, is_admin FROM users");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - User Management</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #ecf0f1;
            color: #2c3e50;
            margin: 0;
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            position: fixed;
            height: 100vh;
        }
        
        /* Password Reset Popup */
        .password-reset-popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            z-index: 1000;
            width: 400px;
            max-width: 90%;
            animation: fadeIn 0.3s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translate(-50%, -60%); }
            to { opacity: 1; transform: translate(-50%, -50%); }
        }
        
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            z-index: 999;
        }
        
        .popup-close {
            position: absolute;
            top: 15px;
            right: 15px;
            background: #1abc9c;
            color: white;
            border: none;
            border-radius: 50%;
            width: 35px;
            height: 35px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            font-size: 18px;
            font-weight: bold;
        }
        
        .popup-close:hover {
            background: #16a085;
            transform: rotate(90deg);
        }
        
        .popup-header {
            margin-bottom: 25px;
            text-align: center;
            color: #2c3e50;
            font-weight: 600;
        }
        
        .popup-body {
            margin-bottom: 25px;
        }
        
        .popup-footer {
            text-align: right;
            margin-top: 20px;
        }
        
        .popup-footer button {
            padding: 8px 15px;
            border-radius: 6px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .popup-footer .btn-secondary {
            background: #f8f9fa;
            color: #2c3e50;
            border: 1px solid #dee2e6;
        }
        
        .popup-footer .btn-secondary:hover {
            background: #e9ecef;
        }
        
        .popup-footer .btn-primary {
            background: #1abc9c;
            color: white;
            border: none;
        }
        
        .popup-footer .btn-primary:hover {
            background: #16a085;
        }
            top: 0;
            left: 0;
            transition: transform 0.3s ease-in-out;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #1abc9c;
            font-size: 24px;
            padding-bottom: 15px;
            border-bottom: 2px solid #1abc9c;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            margin-bottom: 5px;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
        }
        .sidebar ul li a:hover {
            background-color: #1abc9c;
            transform: translateX(5px);
        }
        .sidebar ul li a.active {
            background-color: #1abc9c;
            color: white;
        }
        .sidebar ul li a i {
            margin-right: 10px;
            font-size: 18px;
        }
        .content {
            margin-left: 270px;
            padding: 20px;
            width: calc(100% - 270px);
        }
        .container {
            background: white;
            padding: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .input-container {
            position: relative;
            margin-bottom: 20px;
        }
        .input-container input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        .input-container label {
            position: absolute;
            left: 10px;
            top: 10px;
            font-size: 16px;
            color: #aaa;
            transition: 0.2s ease all;
        }
        .input-container input:focus {
            border-color: #1abc9c;
            outline: none;
        }
        .input-container input:focus + label,
        .input-container input:not(:placeholder-shown) + label {
            top: -8px;
            left: 5px;
            font-size: 12px;
            color: #1abc9c;
            background: white;
            padding: 0 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #1abc9c;
            color: white;
            font-weight: 600;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #d1f2eb;
        }
        .btn {
            background: #1abc9c;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 5px;
            transition: background 0.3s ease, transform 0.2s ease;
            font-weight: 600;
            margin-right: 5px;
        }
        .btn:hover {
            background: #16a085;
            transform: scale(1.05);
        }
        .btn-danger {
            background: #e74c3c;
        }
        .btn-danger:hover {
            background: #c0392b;
        }
        .btn-warning {
            background: #f39c12;
        }
        .btn-warning:hover {
            background: #d35400;
        }
        .alert {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-approved {
            background-color: #d4edda;
            color: #155724;
        }
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        .status-admin {
            background-color: #cce5ff;
            color: #004085;
        }
        .form-row {
            display: flex;
            gap: 20px;
            margin-bottom: 15px;
        }
        .form-group {
            flex: 1;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #2c3e50;
        }
        .form-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        .form-group input:focus {
            border-color: #1abc9c;
            outline: none;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Admin Menu</h2>
        <ul>
        <li><a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="Manage_request.php"><i class="fas fa-tasks"></i> Manage Requests</a></li>
            <li><a href="CRUD.php"><i class="fas fa-box"></i> Manage Products</a></li>
            <li><a href="admin_monitoring.php"><i class="fas fa-desktop"></i> System Monitoring</a></li>
            <li><a href="Approve.php"><i class="fas fa-user-graduate"></i> Students</a></li>
            <li><a href="Records.php"><i class="fas fa-history"></i> Records</a></li>
        </ul>
        <form action="logout.php" method="POST" style="display: inline;">
            <button type="submit" class="btn btn-danger"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
    </div>
    <div class="content">
        <div class="container">
            <h2>User Management</h2>

            <?php if (!empty($error)) : ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <?php if (!empty($success)) : ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>

            <h3>Add New Student</h3>
            <form method="POST" class="mb-4">
                <div class="form-row">
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input type="text" name="name" id="name" required>
                    </div>
                    <div class="form-group">
                        <label for="student_id">Student ID</label>
                        <input type="text" name="student_id" id="student_id" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" required>
                    </div>
                </div>
                <button type="submit" name="add_student" class="btn">Add Student</button>
            </form>

            <h3>User List</h3>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Student ID</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= htmlspecialchars($user['id']); ?></td>
                        <td><?= htmlspecialchars($user['name']); ?></td>
                        <td><?= htmlspecialchars($user['student_id']); ?></td>
                        <td><?= htmlspecialchars($user['email']); ?></td>
                        <td>
                            <span class="status-badge <?= $user['approved'] ? 'status-approved' : 'status-pending' ?>">
                                <?= $user['approved'] ? 'Approved' : 'Pending' ?>
                            </span>
                        </td>
                        <td>
                            <span class="status-badge <?= $user['is_admin'] ? 'status-admin' : '' ?>">
                                <?= $user['is_admin'] ? 'Admin' : 'User' ?>
                            </span>
                        </td>
                        <td>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="user_id" value="<?= $user['id']; ?>">
                                <?php if (!$user['approved']): ?>
                                    <button type="submit" name="approve_user" class="btn btn-success" onclick="return confirm('Are you sure you want to approve this user?')">
                                        <i class="fas fa-check"></i> Approve User
                                    </button>
                                <?php endif; ?>
                            </form>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="user_id" value="<?= $user['id']; ?>">
                                <input type="hidden" name="is_admin" value="<?= $user['is_admin']; ?>">
                                <button type="submit" name="toggle_admin" class="btn btn-warning" onclick="return confirm('Are you sure you want to <?= $user['is_admin'] ? 'remove admin privileges from' : 'make' ?> this user?')">
                                    <i class="fas fa-user-shield"></i> <?= $user['is_admin'] ? 'Remove Admin' : 'Make Admin' ?>
                                </button>
                            </form>
                            <!-- Password Reset Button -->
<button onclick="openPasswordReset('<?= $user['id']; ?>')" class="btn btn-primary">
    <i class="fas fa-key"></i> Reset Password
</button>

<!-- Password Reset Popup -->
<div id="passwordResetPopup" class="password-reset-popup">
    <div class="popup-close" onclick="closePasswordReset()">
        <i class="fas fa-times"></i>
    </div>
    <div class="popup-header">
        <h3>Reset Password</h3>
    </div>
    <form method="POST" action="">
        <input type="hidden" name="user_id" id="popupUserId">
        <div class="popup-body">
            <div class="input-container">
                <input type="password" name="new_password" id="popupPassword" required>
                <label>New Password</label>
            </div>
        </div>
        <div class="popup-footer">
            <button type="button" class="btn btn-secondary" onclick="closePasswordReset()">
                <i class="fas fa-times-circle"></i> Cancel
            </button>
            <button type="submit" name="reset_password" class="btn btn-primary">
                <i class="fas fa-key"></i> Reset Password
            </button>
        </div>
    </form>
</div>

<!-- Overlay -->
<div id="overlay" class="overlay"></div>

<script>
function openPasswordReset(userId) {
    document.getElementById('popupUserId').value = userId;
    document.getElementById('passwordResetPopup').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
    
    // Focus on password input
    setTimeout(function() {
        document.getElementById('popupPassword').focus();
    }, 300);
}

function closePasswordReset() {
    document.getElementById('passwordResetPopup').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
}

// Close popup if clicking outside
document.getElementById('overlay').addEventListener('click', function() {
    closePasswordReset();
});

// Form validation
$(document).ready(function() {
    $('#passwordResetPopup form').submit(function(e) {
        var password = $('#popupPassword').val();
        if (password.length < 6) {
            alert('Password must be at least 6 characters long');
            e.preventDefault();
        }
    });
});
</script>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>