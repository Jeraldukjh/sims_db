<?php
require_once 'api_error_helper.php';

function api_error_response($message, $code = 400, $context = []) {
    log_api_error($message, $context);
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode([
        "status" => "error",
        "message" => $message
    ]);
    exit();
} 