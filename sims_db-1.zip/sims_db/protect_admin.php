<?php
require_once __DIR__ . '/../sims_db/db.php';
require_once __DIR__ . '/api_error_response.php';
header('Content-Type: application/json');

// Example: Protect admin endpoint (adjust logic as needed)
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;

if (!$token) {
    api_error_response('No token provided', 401, ['endpoint' => $_SERVER['PHP_SELF']]);
}

try {
    $stmt = $pdo->prepare("SELECT id, is_admin FROM users WHERE token = :token AND is_admin = 1");
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        api_error_response('Invalid or expired token', 401, ['token' => $token, 'endpoint' => $_SERVER['PHP_SELF']]);
    }

    // If token is valid, proceed to fetch users with all fields
    $stmt = $pdo->prepare("SELECT id, student_id, name, email, created_at, is_admin, role, profile_pic, approved FROM users");
    $stmt->execute();
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode([
        "status" => "success",
        "data" => $students
    ]);
} catch (PDOException $e) {
    api_error_response('Database error: ' . $e->getMessage(), 500, ['query' => 'SELECT id, is_admin FROM users WHERE token = :token AND is_admin = 1', 'endpoint' => $_SERVER['PHP_SELF']]);
}
?>
