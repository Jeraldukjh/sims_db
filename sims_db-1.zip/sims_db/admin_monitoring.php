<?php
session_start();
require_once 'db.php';

// Check if user is admin
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header("Location: login.php");
    exit();
}

// Get system status
function getSystemStatus() {
    global $pdo;
    $status = [
        'database' => ['status' => 'connected', 'message' => 'Database connection successful'],
        'logs' => [],
        'api_status' => [],
        'last_errors' => []
    ];

    // Check log files
    $logFiles = ['api_errors.log', 'error.log', 'db_error_log.txt'];
    foreach ($logFiles as $file) {
        $status['logs'][$file] = [
            'exists' => file_exists($file),
            'size' => file_exists($file) ? filesize($file) : 0,
            'last_modified' => file_exists($file) ? date('Y-m-d H:i:s', filemtime($file)) : null
        ];
    }

    $endpoints = [
        '/protect_admin.php ',
        '/admin_login2.php ',
        '/get_products.php  ',
        '/get_transactions.php  ',
        '/protect_admin.php  ',
        '/create_user.php ',
        '/delete_user.php  ',
        '/create_product.php ',
        '/delete_product.php  ',
        '/get_transactions.php  ',
        '/delete_transaction.php  ',

    ];

    foreach ($endpoints as $endpoint) {
        $ch = curl_init('http://' . $_SERVER['HTTP_HOST'] . $endpoint);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $status['api_status'][$endpoint] = [
            'status' => $httpCode < 400 ? 'ok' : 'error',
            'code' => $httpCode
        ];
    }

    // Get recent errors
    foreach ($logFiles as $file) {
        if (file_exists($file)) {
            $lines = array_slice(file($file), -10);
            $status['last_errors'][$file] = $lines;
        }
    }

    return $status;
}

$systemStatus = getSystemStatus();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Monitoring - Admin Dashboard</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f7f6;
            color: #333;
            margin: 0;
            display: flex;
        }

        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            position: fixed;
            height: 100vh;
            top: 0;
            left: 0;
            transition: transform 0.3s ease-in-out;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            z-index: 1000;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #1abc9c;
            font-size: 24px;
            padding-bottom: 15px;
            border-bottom: 2px solid #1abc9c;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar ul li {
            margin-bottom: 5px;
        }

        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
        }

        .sidebar ul li a:hover {
            background-color: #1abc9c;
            transform: translateX(5px);
        }

        .sidebar ul li a.active {
            background-color: #1abc9c;
            color: white;
        }

        .sidebar ul li a i {
            margin-right: 10px;
            font-size: 18px;
        }

        .content {
            margin-left: 250px;
            padding: 30px;
            flex-grow: 1;
            transition: margin-left 0.3s ease-in-out;
        }

        .dashboard-header {
            background: #1abc9c;
            color: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 15px rgba(26,188,156,0.2);
        }

        .dashboard-header h2 {
            margin: 0;
            font-size: 2rem;
        }

        .status-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: all 0.3s;
            margin-bottom: 20px;
        }

        .status-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .card-header h5 {
            margin: 0;
            color: #2c3e50;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
        }

        .card-header h5 i {
            margin-right: 10px;
            color: #1abc9c;
        }

        .badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .bg-success {
            background: #d4edda;
            color: #155724;
        }

        .bg-danger {
            background: #f8d7da;
            color: #721c24;
        }

        .log-container {
            max-height: 400px;
            overflow-y: auto;
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
        }

        .refresh-btn {
            background: #1abc9c;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(26,188,156,0.2);
        }

        .refresh-btn:hover {
            background: #16a085;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(26,188,156,0.3);
        }
        .logout {
            background: #e74c3c;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            color: white;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }

        .logout:hover {
            background: #c0392b;
        }

        .refresh-btn i {
            margin-right: 8px;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <nav class="sidebar">
        <h2>SIMS</h2>
        <ul>
        <li><a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="Manage_request.php"><i class="fas fa-tasks"></i> Manage Requests</a></li>
            <li><a href="CRUD.php"><i class="fas fa-box"></i> Manage Products</a></li>
            <li><a href="admin_monitoring.php"><i class="fas fa-desktop"></i> System Monitoring</a></li>
            <li><a href="Approve.php"><i class="fas fa-user-graduate"></i> Students</a></li>
            <li><a href="Records.php"><i class="fas fa-history"></i> Records</a></li>
        </ul>
    </nav>

    <main class="content">
        <div class="dashboard-header">
            <h2>System Monitoring</h2>
        </div>

        <div class="row">
            <!-- System Status -->
            <div class="col-md-6">
                <div class="status-card">
                    <div class="card-header">
                        <h5><i class="fas fa-server"></i> System Status</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Database:</strong> 
                            <span class="badge bg-<?php echo $systemStatus['database']['status'] === 'connected' ? 'success' : 'danger'; ?>">
                                <?php echo $systemStatus['database']['status']; ?>
                            </span>
                        </p>
                        <p><strong>Last Updated:</strong> <?php echo date('Y-m-d H:i:s'); ?></p>
                    </div>
                </div>
            </div>

            <!-- API Status -->
            <div class="col-md-6">
                <div class="status-card">
                    <div class="card-header">
                        <h5><i class="fas fa-plug"></i> API Status</h5>
                    </div>
                    <div class="card-body">
                        <?php foreach ($systemStatus['api_status'] as $endpoint => $status): ?>
                            <p><strong><?php echo $endpoint; ?>:</strong>
                                <span class="badge bg-<?php echo $status['status'] === 'ok' ? 'success' : 'danger'; ?>">
                                    <?php echo $status['status']; ?> (<?php echo $status['code']; ?>)
                                </span>
                            </p>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Log Files Status -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="status-card">
                    <div class="card-header">
                        <h5><i class="fas fa-file-alt"></i> Log Files Status</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>File</th>
                                        <th>Status</th>
                                        <th>Size</th>
                                        <th>Last Modified</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($systemStatus['logs'] as $file => $info): ?>
                                        <tr>
                                            <td><?php echo $file; ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $info['exists'] ? 'success' : 'danger'; ?>">
                                                    <?php echo $info['exists'] ? 'Exists' : 'Missing'; ?>
                                                </span>
                                            </td>
                                            <td><?php echo $info['exists'] ? number_format($info['size'] / 1024, 2) . ' KB' : 'N/A'; ?></td>
                                            <td><?php echo $info['last_modified'] ?? 'N/A'; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Login Activity -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="status-card">
                    <div class="card-header">
                        <h5><i class="fas fa-sign-in-alt"></i> Login Activity</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        // Read login logs
                        $loginLogs = [];
                        if (file_exists('login.log')) {
                            $lines = file('login.log', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                            foreach ($lines as $line) {
                                if (strpos($line, '[LOGIN SUCCESS]') !== false) {
                                    $loginLogs[] = $line;
                                }
                            }
                            // Show only the last 20 entries
                            $loginLogs = array_slice($loginLogs, -20);
                        }
                        ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered login-table">
                                <thead class="bg-light">
                                    <tr>
                                        <th class="text-right" >Time</th>
                                        <th class="text-right" >Student ID</th>
                                        <th class="text-right" >Name</th>
                                        <th class="text-right" style="width: 25%">Admin Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($loginLogs as $log): ?>
                                        <?php
                                        // Extract details from log
                                        preg_match('/\[(.+?)\] User logged in: student_id = ([^|]+) \| Name = ([^|]+) \| Is Admin = ([^|]+) \| Time: (.+)/', $log, $matches);
                                        if (isset($matches[2])) {
                                            $time = $matches[5];
                                            $studentId = $matches[2];
                                            $name = $matches[3];
                                            $isAdmin = $matches[4];
                                            ?>
                                            <tr>
                                                <td class="text-left"><?php echo $time; ?></td>
                                                <td class="text-right"><?php echo htmlspecialchars($studentId); ?></td>
                                                <td class="text-left"><?php echo htmlspecialchars($name); ?></td>
                                                <td class="text-center"><?php echo htmlspecialchars($isAdmin); ?></td>
                                            </tr>
                                        <?php }
                                        ?>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Errors -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="status-card">
                    <div class="card-header">
                        <h5><i class="fas fa-exclamation-triangle"></i> Recent Errors</h5>
                    </div>
                    <div class="card-body">
                        <div class="log-container">
                            <?php foreach ($systemStatus['last_errors'] as $file => $errors): ?>
                                <h6 class="mt-3"><?php echo $file; ?></h6>
                                <pre class="bg-light p-3 rounded"><?php echo implode("\n", $errors); ?></pre>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Refresh Button -->
        <button class="refresh-btn" onclick="location.reload()">
            <i class="fas fa-sync-alt"></i> Refresh Status
        </button>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-refresh every 30 seconds
        setTimeout(function() {
            location.reload();
        }, 30000);
    </script>
</body>
</html> 