<?php
session_start();
require_once __DIR__ . '/db.php';

// Ensure the user is logged in as admin
if (!isset($_SESSION['is_admin'])) {
    header("Location: Home.php");
    exit();
}

if (!isset($pdo)) {
    die("Database connection failed.");
}

try {
    // Get counts for all pending requests
    $stmt = $pdo->prepare("
        SELECT 
            (SELECT COUNT(*) FROM inventory_items WHERE status = 'pending') as pending_inventory,
            (SELECT COUNT(*) FROM borrow_requests WHERE status = 'pending') as pending_borrow,
            (SELECT COUNT(*) FROM return_requests WHERE status = 'pending') as pending_returns,
            (SELECT COUNT(*) FROM retrieval_requests WHERE status = 'pending') as pending_retrieval
    ");
    $stmt->execute();
    $counts = $stmt->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SIMS</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #ecf0f1;
            color: #2c3e50;
            margin: 0;
            display: flex;
        }

        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            position: fixed;
            height: 100vh;
            top: 0;
            left: 0;
            transition: transform 0.3s ease-in-out;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            z-index: 1000;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #1abc9c;
            font-size: 24px;
            padding-bottom: 15px;
            border-bottom: 2px solid #1abc9c;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar ul li {
            margin-bottom: 5px;
        }

        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
        }

        .sidebar ul li a:hover,
        .sidebar ul li a.active {
            background-color: #1abc9c;
            color: white;
        }

        .sidebar ul li a i {
            margin-right: 10px;
        }

        .content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
            background-color: #ecf0f1;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .dashboard-header {
            margin-bottom: 30px;
        }

        .dashboard-header h2 {
            font-size: 24px;
            margin: 0;
            color: #2c3e50;
            padding-left: 25px;
        }

        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .dashboard-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            transition: transform 0.3s;
        }

        .dashboard-card:hover {
            transform: translateY(-5px);
        }

        .dashboard-card i {
            font-size: 2.5em;
            margin-bottom: 15px;
            color: #1abc9c;
        }

        .dashboard-card h3 {
            margin: 0 0 10px 0;
            color: #2c3e50;
            font-size: 18px;
        }

        .dashboard-card .count {
            font-size: 2em;
            font-weight: bold;
            color: #1abc9c;
        }

        .dashboard-card .status {
            color: #7f8c8d;
            margin-top: 10px;
            font-size: 14px;
        }

        .logout {
            background: #e74c3c;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            color: white;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }

        .logout:hover {
            background: #c0392b;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Admin Menu</h2>
        <ul>
            <li><a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="Manage_request.php"><i class="fas fa-tasks"></i> Manage Requests</a></li>
            <li><a href="CRUD.php"><i class="fas fa-box"></i> Manage Products</a></li>
            <li><a href="admin_monitoring.php"><i class="fas fa-desktop"></i> System Monitoring</a></li>
            <li><a href="Approve.php"><i class="fas fa-user-graduate"></i> Students</a></li>
            <li><a href="Records.php"><i class="fas fa-history"></i> Records</a></li>
        </ul>
        <a href="logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <div class="content">
        <div class="dashboard-header">
            <h2><i class="fas fa-tachometer-alt"></i> Admin Dashboard</h2>
        </div>

        <div class="dashboard-cards">
            <div class="dashboard-card">
                <h3><i class="fas fa-box"></i> Pending Inventory</h3>
                <a href="manage_request.php" class="pending-link">
                    <div class="count"><?php echo $counts['pending_inventory']; ?></div>
                </a>
                <div class="status">New items waiting for approval</div>
            </div>

            <div class="dashboard-card">
                <h3><i class="fas fa-hand-holding-usd"></i> Pending Borrow Requests</h3>
                <a href="manage_request.php" class="pending-link">
                    <div class="count"><?php echo $counts['pending_borrow']; ?></div>
                </a>
                <div class="status">Borrow requests waiting for approval</div>
            </div>

            <div class="dashboard-card">
                <h3><i class="fas fa-arrow-circle-left"></i> Pending Returns</h3>
                <a href="manage_request.php" class="pending-link">
                    <div class="count"><?php echo $counts['pending_returns']; ?></div>
                </a>
                <div class="status">Return requests waiting for approval</div>
            </div>

            <div class="dashboard-card">
                <h3><i class="fas fa-exchange-alt"></i> Pending Retrievals</h3>
                <a href="manage_request.php" class="pending-link">
                    <div class="count"><?php echo $counts['pending_retrieval']; ?></div>
                </a>
                <div class="status">Retrieval requests waiting for approval</div>
            </div>
        </div>
    </div>
</body>
</html>
