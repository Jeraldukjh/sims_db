<?php
if ($_SERVER['SERVER_NAME'] === 'localhost') { 
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

session_start();

if (!isset($_SESSION['student_id'])) {
    header("Location: home.php");
    exit();
}


require 'db.php';

$studentId = $_SESSION['student_id'];
$username = $_SESSION['username'] ?? 'User';
$isAdmin = $_SESSION['is_admin'] ?? false; 

if (empty($studentId)) {
    die("Error: Session data missing. Please log in again.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['borrow_item'])) {
    $productId = $_POST['product_id'];
    $dueDate = date('Y-m-d', strtotime('+1 day'));

    $stmt = $pdo->prepare("SELECT stock, product_name FROM products WHERE product_id = ?");
    $stmt->execute([$productId]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($product['stock'] > 0) {
        $stmt = $pdo->prepare("INSERT INTO borrow_requests (student_id, product_id, due_date, status) VALUES (?, ?, ?, 'pending')");
        $stmt->execute([$studentId, $productId, $dueDate]);

        $message = "Your borrow request for {$product['product_name']} is pending admin approval. Due date will be set upon approval.";
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, student_id, message, is_read, created_at) VALUES (?, ?, ?, 0, NOW())");
        $stmt->execute([0, $studentId, $message]);

        echo "<script>alert('Borrow request sent successfully!'); window.location.href='dashboard.php';</script>";
        exit();
    } else {
        echo "<script>alert('Item is out of stock!');</script>";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['return_item'])) {
    $productId = $_POST['return_product_id'];

    $stmt = $pdo->prepare("INSERT INTO return_requests (student_id, product_id, status) VALUES (?, ?, 'pending')");
    $stmt->execute([$studentId, $productId]);

    $message = "Your return request for " . $productId . " is pending admin approval.";
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, student_id, message, is_read, created_at) VALUES (?, ?, ?, 0, NOW())");
    $stmt->execute([0, $studentId, $message]);

    echo "<script>alert('Return request sent successfully!'); window.location.href='dashboard.php';</script>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['approve_borrow']) || isset($_POST['reject_borrow'])) {
        $requestId = $_POST['request_id'];
        $action = isset($_POST['approve_borrow']) ? 'approved' : 'rejected';

        $stmt = $pdo->prepare("UPDATE borrow_requests SET status = ? WHERE request_id = ?");
        $stmt->execute([$action, $requestId]);

        $stmt = $pdo->prepare("SELECT student_id, product_id FROM borrow_requests WHERE request_id = ?");
        $stmt->execute([$requestId]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);

        $message = "Your borrow request for product ID " . $request['product_id'] . " has been " . $action . " by the admin.";
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, student_id, message, is_read, created_at) VALUES (?, ?, ?, 0, NOW())");
        $stmt->execute([0, $request['student_id'], $message]);

        echo "<script>alert('Request " . ucfirst($action) . "!'); window.location.href='dashboard.php';</script>";
        exit();
    }
    
    if (isset($_POST['delete_notification'])) {
        $notificationId = $_POST['notification_id'];
        $stmt = $pdo->prepare("DELETE FROM notifications WHERE id = ? AND student_id = ?");
        $stmt->execute([$notificationId, $studentId]);
        header("Location: dashboard.php");
        exit();
    }
    
    if (isset($_POST['delete_selected'])) {
        $selectedIds = explode(',', $_POST['selected_notifications']);
        if (!empty($selectedIds)) {
            $placeholders = str_repeat('?,', count($selectedIds) - 1) . '?';
            $params = array_merge($selectedIds, [$studentId]);
            $stmt = $pdo->prepare("DELETE FROM notifications WHERE id IN ($placeholders) AND student_id = ?");
            $stmt->execute($params);
        }
        header("Location: dashboard.php");
        exit();
    }
    
    if (isset($_POST['mark_read'])) {
        $notificationId = $_POST['notification_id'];
        $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND student_id = ?");
        $stmt->execute([$notificationId, $studentId]);
        header("Location: dashboard.php");
        exit();
    }

    if (isset($_POST['delete_all'])) {
        $stmt = $pdo->prepare("DELETE FROM notifications WHERE student_id = ?");
        $stmt->execute([$studentId]);
        header("Location: dashboard.php");
        exit();
    }
}

$stmt = $pdo->prepare("SELECT p.product_id, p.product_name, DATE_FORMAT(br.due_date, '%b %d, %Y') AS due_date 
                        FROM borrow_requests br
                        JOIN products p ON br.product_id = p.product_id 
                        WHERE br.student_id = ? AND br.status = 'approved'");
$stmt->execute([$studentId]);
$borrowedProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->query("SELECT product_id, product_name, stock FROM products WHERE stock > 0");
$availableProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pendingRequests = [];
if ($isAdmin) {
    $stmt = $pdo->query("SELECT br.request_id, u.name AS username, p.product_name, br.due_date, br.status 
                        FROM borrow_requests br 
                        JOIN users u ON br.student_id = u.student_id
                        JOIN products p ON br.product_id = p.product_id 
                        WHERE br.status = 'pending'");
    $pendingRequests = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

if ($isAdmin) {
    // Admin sees all global notifications (user_id = 0)
    $stmt = $pdo->prepare("SELECT id, message, is_read, created_at FROM notifications WHERE user_id = 0 ORDER BY created_at DESC LIMIT 20");
    $stmt->execute();
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Students see their own notifications
    $stmt = $pdo->prepare("SELECT id, message, is_read, created_at FROM notifications WHERE student_id = ? ORDER BY created_at DESC");
    $stmt->execute([$studentId]);
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$stmt = $pdo->prepare("SELECT profile_pic FROM users WHERE student_id = ?");
$stmt->execute([$studentId]);
$profilePic = $stmt->fetchColumn();

if (!$profilePic) {
    $profilePic = 'uploads/default.png'; 
    echo "Profile pic path: " . $profilePic;
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - SIMS</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f7f6;
            color: #333;
            margin: 0;
            display: flex;
        }

        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            position: fixed;
            height: 100vh;
            top: 0;
            left: 0;
            transition: transform 0.3s ease-in-out;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            z-index: 1000;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #1abc9c;
            font-size: 24px;
            padding-bottom: 15px;
            border-bottom: 2px solid #1abc9c;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar ul li {
            margin-bottom: 5px;
        }

        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
        }

        .sidebar ul li a:hover {
            background-color: #1abc9c;
            transform: translateX(5px);
        }

        .sidebar ul li a.active {
            background-color: #1abc9c;
            color: white;
        }

        .sidebar ul li a i {
            margin-right: 10px;
            font-size: 18px;
        }

        .content {
            margin-left: 250px;
            padding: 30px;
            flex-grow: 1;
            transition: margin-left 0.3s ease-in-out;
        }

        .dashboard-header {
            background: #1abc9c;
            color: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 15px rgba(26,188,156,0.2);
        }

        .dashboard-header h2 {
            margin: 0;
            font-size: 2rem;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }

        .notification-box, .inventory-box {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }

        .notification-box:hover, .inventory-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .notification-header, .inventory-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .notification-header h3, .inventory-header h3 {
            margin: 0;
            color: #2c3e50;
            font-size: 1.5rem;
        }

        .notification-header i, .inventory-header i {
            font-size: 24px;
            color: #1abc9c;
        }

        .notification-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            transition: all 0.3s;
        }

        .notification-item:hover {
            transform: translateX(5px);
            background: #f0f0f0;
        }

        .notification-content {
            margin-bottom: 10px;
        }

        .notification-message {
            font-weight: 500;
            color: #2c3e50;
        }

        .notification-time {
            font-size: 0.85rem;
            color: #666;
        }

        .notification-actions {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }

        .mark-read-btn, .delete-btn {
            padding: 8px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s;
        }

        .mark-read-btn {
            background: #1abc9c;
            color: white;
        }

        .delete-btn {
            background: #e74c3c;
            color: white;
        }

        .mark-read-btn:hover, .delete-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .inventory-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all 0.3s;
        }

        .inventory-item:hover {
            transform: translateX(5px);
            background: #f0f0f0;
        }

        .inventory-content {
            flex-grow: 1;
        }

        .product-name {
            font-weight: 500;
            color: #2c3e50;
            margin-bottom: 5px;
        }

        .inventory-details {
            font-size: 0.9rem;
            color: #666;
        }

        .due-date {
            display: flex;
            align-items: center;
            gap: 5px;
            color: #e74c3c;
        }

        .due-date i {
            color: #e74c3c;
        }

        .return-btn {
            background: #1abc9c;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s;
        }

        .return-btn:hover {
            background: #16a085;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .profile-section {
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 12px;
        }

        .profile-pic {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 15px;
            border: 3px solid #1abc9c;
            transition: all 0.3s;
        }

        .profile-pic:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(26,188,156,0.3);
        }

        .profile-name {
            color: white;
            margin: 10px 0;
            font-size: 1.2rem;
        }

        .custom-file-upload {
            display: inline-block;
            background: #1abc9c;
            color: white;
            padding: 8px 15px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.3s;
            margin: 5px 0;
        }

        .custom-file-upload:hover {
            background: #16a085;
            transform: translateY(-2px);
        }

        #profile-upload {
            display: none;
        }

        .upload-button {
            background: #1abc9c;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.3s;
            margin-top: 5px;
        }

        .upload-button:hover {
            background: #16a085;
            transform: translateY(-2px);
        }

        @media (max-width: 768px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .content {
                margin-left: 0;
            }
        }

        .notification-checkbox {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        #delete-selected-form {
            display: none;
        }
        
        #delete-selected-form.visible {
            display: inline-block;
        }

        .notification-actions-menu {
            position: relative;
            display: inline-block;
        }

        .action-menu-btn {
            background: #1abc9c;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.3s;
        }

        .action-menu-btn:hover {
            background: #16a085;
        }

        .action-menu-dropdown {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 200px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            border-radius: 8px;
            z-index: 1000;
            padding: 8px 0;
        }

        .notification-actions-menu:hover .action-menu-dropdown {
            display: block;
        }

        .menu-item {
            display: block;
            width: 100%;
            padding: 10px 15px;
            text-align: left;
            border: none;
            background: none;
            color: #333;
            cursor: pointer;
            transition: all 0.3s;
        }

        .menu-item:hover {
            background-color: #f5f5f5;
            color: #1abc9c;
        }

        .menu-item i {
            margin-right: 8px;
            width: 20px;
        }

        #selected-count {
            display: inline-block;
            background: #1abc9c;
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 0.9rem;
        }

        #selected-count.visible {
            display: inline-block;
        }
    </style>
</head>
<body>
    <nav class="sidebar">
        <h2>SIMS</h2>
        <div class="profile-section">
            <form action="upload_profile.php" method="POST" enctype="multipart/form-data">
                <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile Picture" class="profile-pic" id="profileImage">
                <label for="profile-upload" class="custom-file-upload">
                    <i class="fas fa-camera"></i> Choose File
                </label>
                <input type="file" id="profile-upload" name="profile_picture" accept="image/*">
                <button type="submit" name="upload" class="upload-button">
                    <i class="fas fa-upload"></i> Upload
                </button>
            </form>
            <h3 class="profile-name"><?php echo htmlspecialchars($username); ?></h3>
        </div>
        <ul>
            <li><a href="dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="borrow_items.php"><i class="fas fa-hand-holding"></i> Borrow Items</a></li>
            <li><a href="return_items.php"><i class="fas fa-undo"></i> Return Requests</a></li>
            <li><a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a></li>
            <li><a href="home.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </nav>

    <main class="content">
        <div class="dashboard-header">
            <h2>Welcome, <?php echo htmlspecialchars($username); ?>!</h2>
        </div>
        
        <div class="dashboard-grid">
            <section class="notification-box">
                <div class="notification-header">
                    <h3><i class="fas fa-bell"></i> Notifications</h3>
                    <div class="notification-actions-menu">
                        <div id="selected-count" style="display: none; margin-right: 10px;">
                            <span id="count-number">0</span> selected
                        </div>
                        <button class="action-menu-btn" id="actionMenuBtn">
                            <i class="fas fa-ellipsis-v"></i> Actions
                        </button>
                        <div class="action-menu-dropdown" id="actionMenu">
                            <form method="POST" id="delete-selected-form" style="display:none;">
                                <input type="hidden" name="selected_notifications" id="selected-notifications">
                                <button type="submit" name="delete_selected" class="menu-item" onclick="return confirm('Are you sure you want to delete selected notifications?')">
                                    <i class="fas fa-trash"></i> Delete Selected
                                </button>
                            </form>
                            <form method="POST" id="delete-all-form" style="display:none;">
                                <button type="submit" name="delete_all" class="menu-item" onclick="return confirm('Are you sure you want to delete all notifications?')">
                                    <i class="fas fa-trash-alt"></i> Delete All
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <ul>
                    <?php if (!empty($notifications)) { ?>
                        <?php foreach ($notifications as $note) { ?>
                            <li class="notification-item <?php echo $note['is_read'] ? 'read' : 'unread'; ?>">
                                <div class="notification-content">
                                    <input type="checkbox" class="notification-checkbox" data-id="<?php echo $note['id']; ?>" style="margin-right: 10px;">
                                    <span class="notification-message"><?php echo htmlspecialchars($note['message']); ?></span>
                                    <div class="notification-details">
                                        <span class="notification-time">
                                            <i class="fas fa-clock"></i>
                                            <?php echo date('M d, Y h:i A', strtotime($note['created_at'])); ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="notification-actions">
                                    <?php if (!$note['is_read']) { ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="notification_id" value="<?php echo $note['id']; ?>">
                                            <button type="submit" name="mark_read" class="mark-read-btn">
                                                <i class="fas fa-check"></i> Mark as Read
                                            </button>
                                        </form>
                                    <?php } ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="notification_id" value="<?php echo $note['id']; ?>">
                                        <button type="submit" name="delete_notification" class="delete-btn" onclick="return confirm('Are you sure you want to delete this notification?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </div>
                            </li>
                        <?php } ?>
                    <?php } else { ?>
                        <li class="notification-item">No new notifications.</li>
                    <?php } ?>
                </ul>
            </section>

            <section class="inventory-box">
                <div class="inventory-header">
                    <h3><i class="fas fa-boxes"></i> Borrowed Products</h3>
                </div>
                <ul>
                    <?php if (!empty($borrowedProducts)) { ?>
                        <?php foreach ($borrowedProducts as $product) { ?>
                            <li class="inventory-item">
                                <div class="inventory-content">
                                    <span class="product-name"><?php echo htmlspecialchars($product['product_name']); ?></span>
                                    <div class="inventory-details">
                                        <span class="due-date">
                                            <i class="fas fa-calendar-alt"></i>
                                            Due: <?php echo $product['due_date']; ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="inventory-actions">
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="return_product_id" value="<?php echo $product['product_id']; ?>">
                                        <button type="submit" name="return_item" class="return-btn">
                                            <i class="fas fa-undo"></i> Return Item
                                        </button>
                                    </form>
                                </div>
                            </li>
                        <?php } ?>
                    <?php } else { ?>
                        <li class="inventory-item">No borrowed products.</li>
                    <?php } ?>
                </ul>
            </section>
        </div>
    </main>

    <script>
        document.getElementById('profile-upload').addEventListener('change', function(event) {
            let reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('profileImage').src = e.target.result;
            }
            reader.readAsDataURL(event.target.files[0]);
        });

        document.addEventListener('DOMContentLoaded', function() {
            const checkboxes = document.querySelectorAll('.notification-checkbox');
            const deleteSelectedForm = document.getElementById('delete-selected-form');
            const deleteAllForm = document.getElementById('delete-all-form');
            const selectedNotificationsInput = document.getElementById('selected-notifications');
            const selectedCount = document.getElementById('selected-count');
            const countNumber = document.getElementById('count-number');
            const actionMenuBtn = document.getElementById('actionMenuBtn');
            const actionMenu = document.getElementById('actionMenu');
            
            // Toggle action menu
            actionMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                actionMenu.classList.toggle('show');
            });

            // Close menu when clicking outside
            document.addEventListener('click', function(e) {
                if (!actionMenu.contains(e.target) && !actionMenuBtn.contains(e.target)) {
                    actionMenu.classList.remove('show');
                }
            });
            
            function updateMenu() {
                const selectedIds = Array.from(checkboxes)
                    .filter(cb => cb.checked)
                    .map(cb => cb.dataset.id);
                if (selectedIds.length > 0) {
                    selectedNotificationsInput.value = selectedIds.join(',');
                    selectedCount.classList.add('visible');
                    countNumber.textContent = selectedIds.length;
                    deleteSelectedForm.style.display = 'block';
                    deleteAllForm.style.display = 'none';
                } else {
                    selectedCount.classList.remove('visible');
                    deleteSelectedForm.style.display = 'none';
                    deleteAllForm.style.display = 'block';
                }
            }
            
            checkboxes.forEach(checkbox => {
                checkbox.addEventListener('change', updateMenu);
            });
            // Initial state
            updateMenu();
        });
    </script>
</body>
</html>