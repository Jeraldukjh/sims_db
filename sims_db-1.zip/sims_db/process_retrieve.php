<?php
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate required fields
    if (!isset($_POST['item_id']) || !isset($_POST['retrieve_reason']) || !isset($_POST['retrieve_date'])) {
        $_SESSION['error'] = "All fields are required.";
        header("Location: inventory.php");
        exit();
    }

    $item_id = filter_var($_POST['item_id'], FILTER_VALIDATE_INT);
    $reason = trim($_POST['retrieve_reason']);
    $preferred_date = trim($_POST['retrieve_date']);

    // Validate student_id is set
    if (!isset($_SESSION['student_id'])) {
        $_SESSION['error'] = "Please log in to submit a retrieval request.";
        header("Location: inventory.php");
        exit();
    }

    try {
        // Start transaction
        $pdo->beginTransaction();
        
        // Get the user's student_id from the session
        $student_id = $_SESSION['student_id'];

        if (!$student_id) {
            throw new Exception("Student ID not found. Please try logging in again.");
        }

        // Check if item exists and is available
        $check_stmt = $pdo->prepare("SELECT id, name, status FROM inventory_items WHERE id = ?");
        $check_stmt->execute([$item_id]);
        $item = $check_stmt->fetch(PDO::FETCH_ASSOC);

        if (!$item) {
            throw new Exception("Item not found.");
        }

        if ($item['status'] !== 'approved') {
            throw new Exception("This item is not available for retrieval.");
        }

        // Check if user already has a pending request for this item
        $check_request = $pdo->prepare("SELECT id FROM retrieval_requests 
                                      WHERE item_id = ? AND student_id = ? AND status = 'pending'");
        $check_request->execute([$item_id, $student_id]);
        if ($check_request->fetch()) {
            throw new Exception("You already have a pending request for this item.");
        }
        
        // Insert the retrieval request
        $stmt = $pdo->prepare("INSERT INTO retrieval_requests (student_id, item_id, reason, preferred_date, status) 
                              VALUES (?, ?, ?, ?, 'pending')");
        $stmt->execute([$student_id, $item_id, $reason, $preferred_date]);
        
        // Get the request ID
        $request_id = $pdo->lastInsertId();
        
        // Get the student's name
        $student_stmt = $pdo->prepare("SELECT name FROM users WHERE id = ?");
        $student_stmt->execute([$student_id]);
        $student = $student_stmt->fetch(PDO::FETCH_ASSOC);
        $student_name = $student ? $student['name'] : 'Unknown Student';

        // Add notification for admin
        $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, message, is_read, created_at) 
                                    VALUES (0, ?, 0, NOW())");
        $notif_message_admin = "New retrieval request submitted by " . htmlspecialchars($student_name) . " for item '" . htmlspecialchars($item['name']) . "'. Reason: " . htmlspecialchars($reason);
        $notif_stmt->execute([$notif_message_admin]);

        // Add notification for user
        $notif_stmt = $pdo->prepare("INSERT INTO notifications (student_id, message, is_read, created_at) 
                                    VALUES (?, ?, 0, NOW())");
        $notif_message_user = "Your retrieval request for item '" . htmlspecialchars($item['name']) . "' is now pending for approval.\nReason: " . htmlspecialchars($reason);
        $notif_stmt->execute([$student_id, $notif_message_user]);
        
        // Commit transaction
        $pdo->commit();
        
        $_SESSION['success'] = "Retrieval request submitted successfully! Waiting for admin approval.";
    } catch (Exception $e) {
        // Rollback transaction on error
        $pdo->rollBack();
        $_SESSION['error'] = $e->getMessage() ?: "Failed to submit retrieval request. Please try again.";
    }
    
    header("Location: inventory.php");
    exit();
}

// If accessed directly without POST data
header("Location: inventory.php");
exit();
?> 