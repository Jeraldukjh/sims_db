<?php
// Start session
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: home.php");
    exit();
}

require 'db.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['return_item']) && isset($_POST['product_id'])) {
    $response = ['status' => 'error', 'message' => ''];
    
    try {
        $checkStmt = $pdo->prepare("
            SELECT COUNT(*) FROM return_requests 
            WHERE student_id = ? AND product_id = ? AND status = 'pending'
        ");
        $checkStmt->execute([$_SESSION['student_id'], $_POST['product_id']]);
        
        if ($checkStmt->fetchColumn() > 0) {
            $response['message'] = 'You already have a pending return request for this item.';
        } else {          // Create new return request
            $stmt = $pdo->prepare("
                INSERT INTO return_requests (student_id, product_id, request_date, status)
                VALUES (?, ?, NOW(), 'pending')
            ");
            
            if ($stmt->execute([$_SESSION['student_id'], $_POST['product_id']])) {
                // Update borrow_requests status to returned
                $updateStmt = $pdo->prepare("
                    UPDATE borrow_requests 
                    SET status = 'returned' 
                    WHERE student_id = ? AND product_id = ? AND status = 'approved'
                ");
                $updateStmt->execute([$_SESSION['student_id'], $_POST['product_id']]);
                
                // Add to records
                $stmt = $pdo->prepare("
                    INSERT INTO records (student_id, product_id, action_type, action_date, status)
                    VALUES (?, ?, 'return_request', NOW(), 'pending')
                ");
                $stmt->execute([$_SESSION['student_id'], $_POST['product_id']]);
                
                $response['status'] = 'success';
                $response['message'] = 'Return request submitted successfully.';
            } else {
                $response['message'] = 'Failed to submit return request.';
            }
        }
    } catch (PDOException $e) {
        $response['message'] = 'Wait for approval';
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Add delete functionality at the top of the file after the existing POST handler
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_rejected']) && isset($_POST['product_id'])) {
    $response = ['status' => 'error', 'message' => ''];
    
    try {
        // Delete the rejected return request
        $stmt = $pdo->prepare("
            DELETE FROM return_requests 
            WHERE student_id = ? AND product_id = ? AND status = 'rejected'
        ");
        
        if ($stmt->execute([$_SESSION['student_id'], $_POST['product_id']])) {
            $response['status'] = 'success';
            $response['message'] = 'Rejected return request deleted successfully.';
        } else {
            $response['message'] = 'Failed to delete rejected return request.';
        }
    } catch (PDOException $e) {
        $response['message'] = 'Error deleting rejected return request.';
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Get session data
$studentId = $_SESSION['student_id'];
$username = $_SESSION['username'] ?? 'User  ';


$stmt = $pdo->prepare("
    SELECT bp.request_id, bp.student_id, bp.due_date, bp.product_id, p.product_name, p.category, p.image_url,
           COALESCE(rr.status, 'none') as return_status, bp.status as borrow_status
    FROM borrow_requests bp
    JOIN products p ON bp.product_id = p.product_id
    LEFT JOIN (
        SELECT r1.product_id, r1.student_id, r1.status
        FROM return_requests r1
        INNER JOIN (
            SELECT product_id, student_id, MAX(request_date) AS max_date
            FROM return_requests
            WHERE student_id = ? AND status IN ('pending', 'rejected')
            GROUP BY product_id, student_id
        ) r2 ON r1.product_id = r2.product_id AND r1.student_id = r2.student_id AND r1.request_date = r2.max_date
    ) rr ON rr.product_id = bp.product_id AND rr.student_id = bp.student_id
    WHERE bp.student_id = ? 
    AND bp.status = 'approved'
    GROUP BY bp.product_id
    ORDER BY bp.request_id DESC
");

$stmt->execute([$studentId, $studentId]);
$borrowedItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return Items - SIMS</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f7f6;
            color: #333;
            margin: 0;
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            position: fixed;
            height: 100vh;
            top: 0;
            left: 0;
            transition: transform 0.3s ease-in-out;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #1abc9c;
            font-size: 24px;
            padding-bottom: 15px;
            border-bottom: 2px solid #1abc9c;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            margin-bottom: 5px;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
        }
        .sidebar ul li a:hover {
            background-color: #1abc9c;
            transform: translateX(5px);
        }
        .sidebar ul li a.active {
            background-color: #1abc9c;
            color: white;
        }
        .sidebar ul li a i {
            margin-right: 10px;
            font-size: 18px;
        }
        .content {
            margin-left: 250px;
            padding: 30px;
            flex-grow: 1;
            transition: margin-left 0.3s ease-in-out;
        }
        .dashboard-header {
            background: #1abc9c;
            color: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 15px rgba(26,188,156,0.2);
        }
        .dashboard-header h2 {
            margin: 0;
            font-size: 2rem;
        }
        .items-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        .item-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }
        .item-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .item-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .item-card h3 {
            margin: 0 0 10px 0;
            color: #2c3e50;
        }
        .item-card p {
            color: #666;
            margin: 5px 0;
        }
        .status-badge {
            position: absolute;
            top: 15px;
            right: 15px;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        .status-approved {
            background: #d4edda;
            color: #155724;
        }
        .status-returned {
            background: #cce5ff;
            color: #004085;
        }
        .status-rejected {
            background: #f8d7da;
            color: #721c24;
        }
        .return-btn {
            background: #1abc9c;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            width: 100%;
            margin-top: 15px;
            transition: all 0.3s;
        }
        .return-btn:hover {
            background: #16a085;
            transform: translateY(-2px);
        }
        .return-btn:disabled {
            background: #95a5a6;
            cursor: not-allowed;
            transform: none;
        }
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .button-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .delete-btn {
            background: #e74c3c;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            width: 100%;
            transition: all 0.3s;
        }
        .delete-btn:hover {
            background: #c0392b;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <nav class="sidebar">
        <h2>SIMS</h2>
        <ul>
            <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="borrow_items.php"><i class="fas fa-hand-holding"></i> Borrow Items</a></li>
            <li><a href="return_items.php" class="active"><i class="fas fa-undo"></i> Return Requests</a></li>
            <li><a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a></li>
            <li><a href="home.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </nav>

    <main class="content">
        <div class="dashboard-header">
            <h2>Return Items</h2>
        </div>

        <div class="items-grid">
            <?php foreach ($borrowedItems as $item): ?>
                <div class="item-card">
                    <span class="status-badge status-<?php echo strtolower($item['return_status'] === 'none' ? $item['borrow_status'] : $item['return_status']); ?>">
                        <?php echo ucfirst($item['return_status'] === 'none' ? $item['borrow_status'] : $item['return_status']); ?>
                    </span>
                    <?php if (!empty($item['image_url'])): ?>
                        <img src="<?php echo htmlspecialchars($item['image_url']); ?>" alt="<?php echo htmlspecialchars($item['product_name']); ?>">
                    <?php else: ?>
                        <img src="uploads/no-image.png" alt="No image">
                    <?php endif; ?>
                    <h3><?php echo htmlspecialchars($item['product_name']); ?></h3>
                    <p><strong>Category:</strong> <?php echo htmlspecialchars($item['category']); ?></p>
                    <p><strong>Due Date:</strong> <?php echo date('M d, Y', strtotime($item['due_date'])); ?></p>
                    <?php if ($item['return_status'] === 'none' && $item['borrow_status'] === 'approved'): ?>
                        <button class="return-btn" onclick="returnItem(<?php echo $item['product_id']; ?>, this)">
                            <i class="fas fa-undo"></i> Return Item
                        </button>
                    <?php elseif ($item['return_status'] === 'rejected'): ?>
                        <div class="button-group">
                            <button class="return-btn" onclick="returnItem(<?php echo $item['product_id']; ?>, this)">
                                <i class="fas fa-undo"></i> Return Item (Rejected)
                            </button>
                            <button class="delete-btn" type="button" onclick="deleteRejected(<?php echo $item['product_id']; ?>, this); event.stopPropagation();">
                                <i class="fas fa-trash"></i> Delete Rejected Request
                            </button>
                        </div>
                    <?php else: ?>
                        <button class="return-btn" disabled>
                            <?php 
                            if ($item['return_status'] === 'pending') {
                                echo 'Return Request Pending';
                            } elseif ($item['return_status'] === 'rejected') {
                                echo 'Return Request Rejected';
                            } else {
                                echo 'Already Returned';
                            }
                            ?>
                        </button>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <script>
        function returnItem(productId, btn) {
            if (confirm('Are you sure you want to return this item?')) {
                // Immediately update UI to show pending status
                btn.disabled = true;
                btn.innerHTML = '<i class="fas fa-clock"></i> Return Request Pending';

                // Update status badge
                const statusBadge = btn.closest('.item-card').querySelector('.status-badge');
                statusBadge.className = 'status-badge status-pending';
                statusBadge.textContent = 'Pending';

                $.ajax({
                    url: 'return_items.php',
                    method: 'POST',
                    data: {
                        return_item: true,
                        product_id: productId
                    },
                    success: function(response) {
                        const result = JSON.parse(response);
                        if (result.status === 'success') {
                            alert(result.message);
                        } else {
                            alert(result.message);
                            // Revert UI changes if there was an error
                            btn.disabled = false;
                            btn.innerHTML = '<i class="fas fa-undo"></i> Return Item';
                            statusBadge.className = 'status-badge status-approved';
                            statusBadge.textContent = 'Approved';
                        }
                    },
                    error: function() {
                        alert('An error occurred. Please try again.');
                        // Revert UI changes if there was an error
                        btn.disabled = false;
                        btn.innerHTML = '<i class="fas fa-undo"></i> Return Item';
                        statusBadge.className = 'status-badge status-approved';
                        statusBadge.textContent = 'Approved';
                    }
                });
            }
        }

        function deleteRejected(productId, btn) {
            if (confirm('Are you sure you want to delete this rejected return request?')) {
                $.ajax({
                    url: 'return_items.php',
                    method: 'POST',
                    data: {
                        delete_rejected: true,
                        product_id: productId
                    },
                    success: function(response) {
                        const result = JSON.parse(response);
                        if (result.status === 'success') {
                            alert(result.message);
                            // Remove the item card from the UI
                            btn.closest('.item-card').remove();
                        } else {
                            alert(result.message);
                        }
                    },
                    error: function() {
                        alert('An error occurred while deleting the rejected request.');
                    }
                });
            }
        }
    </script>
</body>
</html>
 