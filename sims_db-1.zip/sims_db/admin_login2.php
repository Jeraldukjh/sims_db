<?php
require_once __DIR__ . '/../sims_db/db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        "status" => "error",
        "message" => "Method not allowed. Use POST."
    ]);
    exit();
}

// Get login data from the request body
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['student_id']) || !isset($data['password'])) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Missing student_id or password."
    ]);
    exit();
}

$studentId = $data['student_id'];
$password = $data['password'];

global $pdo;
try {
    $stmt = $pdo->prepare("SELECT id, student_id, password, is_admin FROM users WHERE student_id = :student_id");
    $stmt->bindParam(':student_id', $studentId);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(401);
        echo json_encode([
            "status" => "error",
            "message" => "User not found."
        ]);
        exit();
    }

    if (!$user['is_admin']) {
        http_response_code(403);
        echo json_encode([
            "status" => "error",
            "message" => "Only admin users can log in."
        ]);
        exit();
    }

    if (!password_verify($password, $user['password'])) {
        http_response_code(401);
        echo json_encode([
            "status" => "error",
            "message" => "Invalid password."
        ]);
        exit();
    }

    // Generate a token
    $token = generateToken($studentId);
    $updateStmt = $pdo->prepare("UPDATE users SET token = :token WHERE id = :id");
    $updateStmt->bindParam(':token', $token);
    $updateStmt->bindParam(':id', $user['id']);
    $updateStmt->execute();

    echo json_encode([
        "status" => "success",
        "token" => $token
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Database error: " . $e->getMessage()
    ]);
}

function generateToken($studentId) {
    return md5($studentId . time() . rand(1, 10000));
}
?>
