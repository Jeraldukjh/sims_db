<?php
session_start();
require_once 'db.php'; // Make sure this file sets up $pdo (PDO connection)

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Handle edit/delete actions
        $item_id = $_POST['item_id'];
        
        if ($_POST['action'] === 'edit') {
            $name = trim($_POST['name']);
            $description = trim($_POST['description']);
            $quantity = intval($_POST['quantity']);
            $category = trim($_POST['category']);
            $condition = trim($_POST['condition']);

            $stmt = $pdo->prepare("UPDATE inventory_items SET name = ?, description = ?, quantity = ?, category = ?, item_condition = ? WHERE id = ?");
            if ($stmt->execute([$name, $description, $quantity, $category, $condition, $item_id])) {
                $_SESSION['success'] = "Item updated successfully!";
            } else {
                $_SESSION['error'] = "Failed to update item.";
            }
        } elseif ($_POST['action'] === 'delete') {
            $stmt = $pdo->prepare("DELETE FROM inventory_items WHERE id = ?");
            if ($stmt->execute([$item_id])) {
                $_SESSION['success'] = "Item deleted successfully!";
            } else {
                $_SESSION['error'] = "Failed to delete item.";
            }
        }
    } else {
        // Handle new item addition
        $name = trim($_POST['name']);
        $description = trim($_POST['description']);
        $quantity = intval($_POST['quantity']);
        $category = trim($_POST['category']);
        $condition = trim($_POST['condition']);
        $image_url = '';

        // Handle image upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            if (in_array($_FILES['image']['type'], $allowed_types)) {
                $target_dir = "uploads/";
                if (!file_exists($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }
                $target_file = $target_dir . time() . '_' . basename($_FILES["image"]["name"]);
                if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                    $image_url = $target_file;
                } else {
                    $_SESSION['error'] = "Error uploading image.";
                }
            } else {
                $_SESSION['error'] = "Invalid image type. Please upload JPG, PNG, or GIF.";
            }
        }

        if (empty($_SESSION['error'])) {
            // Check if user is logged in
            $student_id = isset($_SESSION['student_id']) ? $_SESSION['student_id'] : null;
            
            $stmt = $pdo->prepare("INSERT INTO inventory_items (name, description, quantity, category, item_condition, image_url, status, student_id) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)");
            if ($stmt->execute([$name, $description, $quantity, $category, $condition, $image_url, $_SESSION['student_id']])) {
                // Add notification for admin
                $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, message, is_read, created_at) VALUES (0, ?, 0, NOW())");
                $notif_message = "A new inventory item ('" . $name . "') has been submitted and is pending approval.";
                $notif_stmt->execute([$notif_message]);
                $_SESSION['success'] = "Item added successfully! Waiting for admin approval.";
                // Store last added item for popup
                $_SESSION['last_added_item'] = [
                    'name' => $name,
                    'description' => $description,
                    'quantity' => $quantity,
                    'category' => $category,
                    'condition' => $condition,
                    'image_url' => $image_url
                ];
            } else {
                $_SESSION['error'] = "Failed to add item.";
            }
        }
    }
    header("Location: inventory.php");
    exit();
}

// Fetch all inventory items
$stmt = $pdo->prepare("
    SELECT i.*, 
           CASE 
               WHEN EXISTS (
                   SELECT 1 FROM retrieval_requests rr 
                   WHERE rr.item_id = i.id 
                   AND rr.status = 'pending'
               ) THEN 'pending_retrieval'
               ELSE i.status 
           END as display_status
    FROM inventory_items i 
    WHERE (i.status = 'approved' AND i.quantity > 0)
    OR EXISTS (
        SELECT 1 FROM retrieval_requests rr 
        WHERE rr.item_id = i.id 
        AND rr.status = 'pending'
    )
    ORDER BY i.created_at DESC
");
$stmt->execute();
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

$studentId = isset($_SESSION['student_id']) ? $_SESSION['student_id'] : null;
if (!$studentId) {
    die('Student ID not set!');
}

$isAdmin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];

if ($isAdmin) {
    // Admin sees all global notifications (user_id = 0)
    $stmt = $pdo->prepare("SELECT id, message, is_read, created_at FROM notifications WHERE user_id = 0 ORDER BY created_at DESC LIMIT 20");
    $stmt->execute();
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Students see their own notifications
    $stmt = $pdo->prepare("SELECT id, message, is_read, created_at FROM notifications WHERE student_id = ? ORDER BY created_at DESC");
    $stmt->execute([$studentId]);
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f7f6;
            color: #333;
            margin: 0;
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            position: fixed;
            height: 100vh;
            top: 0;
            left: 0;
            transition: transform 0.3s ease-in-out;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #1abc9c;
            font-size: 24px;
            padding-bottom: 15px;
            border-bottom: 2px solid #1abc9c;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            margin-bottom: 5px;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
        }
        .sidebar ul li a:hover {
            background-color: #1abc9c;
            transform: translateX(5px);
        }
        .sidebar ul li a.active {
            background-color: #1abc9c;
            color: white;
        }
        .sidebar ul li a i {
            margin-right: 10px;
            font-size: 18px;
        }
        .content {
            margin-left: 250px;
            padding: 30px;
            flex-grow: 1;
            transition: margin-left 0.3s ease-in-out;
        }
        .dashboard-header {
            background: #1abc9c;
            color: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 15px rgba(26,188,156,0.2);
        }
        .dashboard-header h2 {
            margin: 0;
            font-size: 2rem;
        }
        .add-item-btn {
            background: white;
            color: #1abc9c;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 2px 8px rgba(44,62,80,0.1);
        }
        .add-item-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(44,62,80,0.15);
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0,0,0,0.5);
            backdrop-filter: blur(5px);
        }
        .modal-content {
            background: white;
            margin: 50px auto;
            padding: 30px;
            border-radius: 16px;
            width: 90%;
            max-width: 500px;
            position: relative;
            box-shadow: 0 8px 32px rgba(44,62,80,0.2);
            animation: modalSlideIn 0.3s ease-out;
        }
        @keyframes modalSlideIn {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        .close-modal {
            position: absolute;
            right: 20px;
            top: 20px;
            font-size: 24px;
            color: #666;
            cursor: pointer;
            transition: color 0.3s;
        }
        .close-modal:hover {
            color: #e74c3c;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #2c3e50;
            font-weight: 500;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.3s;
            background: #f8f9fa;
        }
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: #1abc9c;
            outline: none;
            box-shadow: 0 0 0 3px rgba(26,188,156,0.1);
        }
        .inventory-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        .inventory-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }
        .inventory-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .inventory-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .inventory-card h3 {
            margin: 0 0 10px 0;
            color: #2c3e50;
        }
        .inventory-card p {
            color: #666;
            margin: 5px 0;
        }
        .status-badge {
            position: absolute;
            top: 15px;
            right: 15px;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        .status-pending_retrieval {
            background: #cce5ff;
            color: #004085;
        }
        .status-approved {
            background: #d4edda;
            color: #155724;
        }
        .status-rejected {
            background: #f8d7da;
            color: #721c24;
        }
        .card-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
        .card-actions button {
            flex: 1;
            padding: 8px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s;
        }
        .edit-btn {
            background: #1abc9c;
            color: white;
        }
        .delete-btn {
            background: #e74c3c;
            color: white;
        }
        .edit-btn:hover, .delete-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .return-btn {
            background: #2ecc71;
            color: white;
        }
        .return-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .retrieve-btn {
            background: #e67e22;
            color: white;
        }
        .retrieve-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
    </style>
</head>
<body>
    <nav class="sidebar">
        <h2>SIMS</h2>
        <ul>
            <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="borrow_items.php"><i class="fas fa-hand-holding"></i> Borrow Items</a></li>
            <li><a href="return_items.php"><i class="fas fa-undo"></i> Return Requests</a></li>
            <li><a href="inventory.php" class="active"><i class="fas fa-boxes"></i> Inventory</a></li>
            <li><a href="home.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </nav>

    <main class="content">
        <div class="dashboard-header">
            <h2>Inventory Management</h2>
            <button id="showAddItemModal" class="add-item-btn">+ Add New Item</button>
        </div>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>

        <div id="addItemModal" class="modal">
            <div class="modal-content">
                <span class="close-modal">&times;</span>
                <h3>Add New Item</h3>
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name">Item Name</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="quantity">Quantity</label>
                        <input type="number" id="quantity" name="quantity" min="0" required>
                    </div>
                    <div class="form-group">
                        <label for="category">Category</label>
                        <select id="category" name="category" required>
                            <option value="">Select Category</option>
                            <option value="Input Devices">Input Devices</option>
                            <option value="Output Devices">Output Devices</option>
                            <option value="Storage Devices">Storage Devices</option>
                            <option value="Networking">Networking</option>
                            <option value="Accessories">Accessories</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="condition">Item Condition</label>
                        <select id="condition" name="condition" required>
                            <option value="">Select Condition</option>
                            <option value="New">New</option>
                            <option value="Like New">Like New</option>
                            <option value="Good">Good</option>
                            <option value="Fair">Fair</option>
                            <option value="Poor">Poor</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="image">Item Image</label>
                        <input type="file" id="image" name="image" accept="image/*">
                    </div>
                    <button type="submit" class="add-item-btn">Add Item</button>
                </form>
            </div>
        </div>

        <div id="returnItemModal" class="modal">
            <div class="modal-content">
                <span class="close-modal">&times;</span>
                <h3>Retrieve Item</h3>
                <form method="POST" action="process_retrieve.php">
                    <input type="hidden" name="item_id" id="return_item_id">
                    <div class="form-group">
                        <label for="return_condition">Item Condition</label>
                        <select id="return_condition" name="return_condition" required>
                            <option value="">Select Condition</option>
                            <option value="Good">Good</option>
                            <option value="Damaged">Damaged</option>
                            <option value="Lost">Lost</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="return_notes">Notes</label>
                        <textarea id="return_notes" name="return_notes" rows="3" placeholder="Add any notes about the item's condition or issues"></textarea>
                    </div>
                    <button type="submit" class="add-item-btn">Submit Retrieval</button>
                </form>
            </div>
        </div>

        <div id="retrieveItemModal" class="modal">
            <div class="modal-content">
                <span class="close-modal">&times;</span>
                <h3>Request Item Retrieval</h3>
                <form method="POST" action="process_retrieve.php">
                    <input type="hidden" name="item_id" id="retrieve_item_id">
                    <div class="form-group">
                        <label for="retrieve_reason">Reason for Retrieval</label>
                        <textarea id="retrieve_reason" name="retrieve_reason" rows="3" required placeholder="Please explain why you need to retrieve this item"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="retrieve_date">Preferred Retrieval Date</label>
                        <input type="date" id="retrieve_date" name="retrieve_date" required min="<?= date('Y-m-d') ?>">
                    </div>
                    <button type="submit" class="add-item-btn">Submit Retrieval Request</button>
                </form>
            </div>
        </div>

        <div id="pendingApprovalModal" class="modal">
            <div class="modal-content">
                <span class="close-modal">&times;</span>
                <h3>Pending for Approval</h3>
                <div id="pendingItemDetails"></div>
            </div>
        </div>

        <div class="inventory-grid">
            <?php foreach ($items as $item): ?>
                <div class="inventory-card">
                    <span class="status-badge status-<?= strtolower($item['display_status']); ?>">
                        <?= $item['display_status'] === 'pending_retrieval' ? 'Pending Retrieval' : ucfirst($item['status']); ?>
                    </span>
                    <?php if (!empty($item['image_url'])): ?>
                        <img src="<?= htmlspecialchars($item['image_url']); ?>" alt="<?= htmlspecialchars($item['name']); ?>">
                    <?php else: ?>
                        <img src="uploads/no-image.png" alt="No image">
                    <?php endif; ?>
                    <h3><?= htmlspecialchars($item['name']); ?></h3>
                    <p><strong>Category:</strong> <?= htmlspecialchars($item['category']); ?></p>
                    <p><strong>Condition:</strong> <?= htmlspecialchars($item['item_condition']); ?></p>
                    <p><strong>Quantity:</strong> <?= htmlspecialchars($item['quantity']); ?></p>
                    <p><strong>Description:</strong> <?= htmlspecialchars($item['description']); ?></p>
                    <div class="card-actions">
                        <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                            <button class="retrieve-btn" onclick="retrieveItem(<?= $item['id']; ?>)">Retrieve</button>
                        <?php else: ?>
                            <button class="retrieve-btn" onclick="retrieveItem(<?= $item['id']; ?>)">Retrieve</button>
                        <?php endif; ?>
                        <button class="delete-btn" onclick="deleteItem(<?= $item['id']; ?>)">Delete</button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <script>
        $(document).ready(function() {
            // Show modal
            $('#showAddItemModal').click(function() {
                $('#addItemModal').fadeIn();
            });

            // Close modal
            $('.close-modal').click(function() {
                $('#addItemModal').fadeOut();
                $('#returnItemModal').fadeOut();
                $('#retrieveItemModal').fadeOut();
            });

            // Close modal when clicking outside
            $(window).click(function(e) {
                if ($(e.target).is('.modal')) {
                    $('.modal').fadeOut();
                }
            });

            // Set minimum date for retrieve_date to today
            $('#retrieve_date').attr('min', new Date().toISOString().split('T')[0]);
        });

        function editItem(item) {
            // Populate form with item data
            $('#name').val(item.name);
            $('#description').val(item.description);
            $('#quantity').val(item.quantity);
            $('#category').val(item.category);
            $('#condition').val(item.item_condition);
            
            // Show modal
            $('#addItemModal').fadeIn();
            
            // Add hidden input for item_id and action
            if (!$('input[name="item_id"]').length) {
                $('form').append('<input type="hidden" name="item_id" value="' + item.id + '">');
                $('form').append('<input type="hidden" name="action" value="edit">');
            } else {
                $('input[name="item_id"]').val(item.id);
                $('input[name="action"]').val('edit');
            }
        }

        function deleteItem(itemId) {
            if (confirm('Are you sure you want to delete this item?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="item_id" value="${itemId}">
                    <input type="hidden" name="action" value="delete">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function returnItem(itemId) {
            $('#return_item_id').val(itemId);
            $('#returnItemModal').fadeIn();
        }

        function retrieveItem(itemId) {
            // Reset form
            $('#retrieveItemModal form')[0].reset();
            // Set item ID
            $('#retrieve_item_id').val(itemId);
            // Show modal
            $('#retrieveItemModal').fadeIn();
        }
    </script>

    <?php if (isset($_SESSION['last_added_item'])): ?>
    <script>
        $(document).ready(function() {
            // Fill in the item details
            var item = <?= json_encode($_SESSION['last_added_item']); ?>;
            var html = `
                <p><strong>Name:</strong> ${item.name}</p>
                <p><strong>Description:</strong> ${item.description}</p>
                <p><strong>Quantity:</strong> ${item.quantity}</p>
                <p><strong>Category:</strong> ${item.category}</p>
                <p><strong>Condition:</strong> ${item.condition}</p>
                ${item.image_url ? `<img src='${item.image_url}' style='max-width:100%;border-radius:8px;margin-top:10px;'>` : ''}
            `;
            $('#pendingItemDetails').html(html);
            $('#pendingApprovalModal').fadeIn();
            $('.close-modal').click(function() {
                $('#pendingApprovalModal').fadeOut();
            });
            $(window).click(function(e) {
                if ($(e.target).is('#pendingApprovalModal')) {
                    $('#pendingApprovalModal').fadeOut();
                }
            });
        });
    </script>
    <?php unset($_SESSION['last_added_item']); ?>
    <?php endif; ?>
</body>
</html>
