<?php
require_once __DIR__ . '/db.php';
header('Content-Type: application/json');

// Get the token from the Authorization header
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;

if (!$token) {
    http_response_code(401);
    echo json_encode([
        "status" => "error",
        "message" => "No token provided"
    ]);
    exit();
}

try {
    $stmt = $pdo->prepare("SELECT id, is_admin FROM users WHERE token = :token AND is_admin = 1");
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        http_response_code(401);
        echo json_encode([
            "status" => "error",
            "message" => "Invalid or expired token"
        ]);
        exit();
    }

    // Get all users
    $stmt = $pdo->prepare("
        SELECT 
            id,
            student_id,
            name,
            email,
            created_at,
            is_admin,
            role,
            profile_pic,
            approved
        FROM users
        ORDER BY id DESC
    ");
    
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        "status" => "success",
        "data" => $users
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Database error: " . $e->getMessage()
    ]);
}
?> 