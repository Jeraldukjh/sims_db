<?php
session_start();
require_once __DIR__ . '/db.php';

// Ensure the user is logged in as admin
if (!isset($_SESSION['is_admin'])) {
    header("Location: Home.php");
    exit();
}

if (!isset($pdo)) {
    die("Database connection failed.");
}

try {
    // Get search term from URL
    $searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';
    $searchTerm = $pdo->quote('%' . $searchTerm . '%');

    // Fetch pending borrow requests with student and product details
    $stmt = $pdo->prepare("
        SELECT br.request_id, br.product_id, br.barcode, br.due_date, br.status, br.request_date, br.student_id, COALESCE(u.name, 'Unknown') AS student_name, p.product_name 
        FROM borrow_requests br
        LEFT JOIN users u ON br.student_id = u.student_id
        LEFT JOIN products p ON br.product_id = p.product_id
        WHERE br.status = 'pending'
    ");
    $stmt->execute();
    $pendingRequests = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch pending return requests with student and product details
    $stmt = $pdo->prepare("
        SELECT rr.request_id, rr.student_id, COALESCE(u.name, 'Unknown') AS student_name, p.product_name 
        FROM return_requests rr
        LEFT JOIN users u ON rr.student_id = u.student_id
        LEFT JOIN products p ON rr.product_id = p.product_id
        WHERE rr.status = 'pending'
    ");
    $stmt->execute();
    $pendingReturns = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch pending inventory items
    $stmt = $pdo->prepare("
        SELECT id, name, description, quantity, category, item_condition, image_url, created_at
        FROM inventory_items
        WHERE status = 'pending'
        ORDER BY created_at DESC
    ");
    $stmt->execute();
    $pendingInventory = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch pending retrieval requests
    $stmt = $pdo->prepare("
        SELECT rr.id as request_id, rr.reason, rr.preferred_date, rr.created_at as request_date,
               rr.student_id, COALESCE(u.name, 'Unknown') as student_name, i.name as item_name
        FROM retrieval_requests rr
        LEFT JOIN users u ON rr.student_id = u.student_id
        JOIN inventory_items i ON rr.item_id = i.id
        WHERE rr.status = 'pending'
        ORDER BY rr.created_at DESC
    ");
    $stmt->execute();
    $pendingRetrieves = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Handle approve button: move approved borrow requests to borrowed_products table
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['approve_request_id'])) {
        $requestId = $_POST['approve_request_id'];

        // Get product and student details for the approved request
        $stmt = $pdo->prepare("SELECT product_id, student_id FROM borrow_requests WHERE request_id = :request_id");
        $stmt->execute(['request_id' => $requestId]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($request) {
            // Set due date to 1 day from now
            $dueDate = date('Y-m-d', strtotime('+1 day'));

            // Insert into borrowed_products table
            $stmt = $pdo->prepare("
                INSERT INTO borrowed_products (product_id, student_id, due_date)
                VALUES (:product_id, :student_id, :due_date)
            ");
            $stmt->execute([
                'product_id' => $request['product_id'],
                'student_id' => $request['student_id'],
                'due_date'   => $dueDate
            ]);

            // Update borrow_requests status and due date
            $stmt = $pdo->prepare("UPDATE borrow_requests SET status = 'approved', due_date = :due_date WHERE request_id = :request_id");
            $stmt->execute([
                'due_date'   => $dueDate,
                'request_id' => $requestId
            ]);

            // Send notification
            if (isset($request['student_id']) && isset($request['product_id'])) {
                $message = "Your borrow request for item ID {$request['product_id']} has been approved.";
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO notifications (user_id, student_id, message, is_read, created_at)
                        VALUES (0, :student_id, :message, 0, NOW())
                    ");
                    $stmt->execute([
                        'student_id' => $request['student_id'],
                        'message'    => $message
                    ]);
                } catch (PDOException $e) {
                    echo "Database error: " . $e->getMessage();
                }
            }
        }
    }

    // Handle inventory item approval
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['approve_inventory_id'])) {
        $id = $_POST['approve_inventory_id'];
        $stmt = $pdo->prepare("UPDATE inventory_items SET status = 'approved' WHERE id = ?");
        if ($stmt->execute([$id])) {
            // Get item name for notification
            $itemStmt = $pdo->prepare("SELECT name FROM inventory_items WHERE id = ?");
            $itemStmt->execute([$id]);
            $item = $itemStmt->fetch(PDO::FETCH_ASSOC);
            $itemName = $item ? $item['name'] : 'Unknown Item';

            // Send notification to admin dashboard (user_id = 0)
            $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, student_id, message, is_read, created_at) VALUES (0, NULL, ?, 0, NOW())");
            $notif_message = "Inventory item ('" . $itemName . "') has been approved and is now available.";
            $notif_stmt->execute([$notif_message]);

            echo "Approval successful!";
        } else {
            echo "Error approving inventory item.";
        }
        exit;
    }

    // Handle inventory item rejection
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reject_inventory_id'])) {
        $inventoryId = $_POST['reject_inventory_id'];
        try {
            // Update inventory item status to rejected
            $stmt = $pdo->prepare("UPDATE inventory_items SET status = 'rejected' WHERE id = :id");
            $stmt->execute(['id' => $inventoryId]);
            echo "Inventory item rejected successfully!";
        } catch (PDOException $e) {
            echo "Error rejecting inventory item: " . $e->getMessage();
        }
        exit; // <-- SIGURADUHIN NA MAY EXIT DITO
    }

    // Handle retrieval request approval
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['approve_retrieve_id'])) {
        $requestId = $_POST['approve_retrieve_id'];
        try {
            // Start transaction
            $pdo->beginTransaction();
            
            // Get request details first
            $stmt = $pdo->prepare("
                SELECT rr.student_id, rr.item_id, i.name as item_name, i.quantity
                FROM retrieval_requests rr
                LEFT JOIN inventory_items i ON rr.item_id = i.id
                WHERE rr.id = ?
            ");
            $stmt->execute([$requestId]);
            $request = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$request) {
                throw new Exception("Retrieval request not found.");
            }

            // Update retrieval request status
            $stmt = $pdo->prepare("UPDATE retrieval_requests SET status = 'approved' WHERE id = ?");
            $stmt->execute([$requestId]);
            
            // Only update inventory quantity if the request was successfully approved
            if ($stmt->rowCount() > 0) {
                // Update inventory quantity
                $stmt = $pdo->prepare("UPDATE inventory_items SET quantity = quantity - 1 WHERE id = ?");
                $stmt->execute([$request['item_id']]);
            }
            
            // Add notification
            $notif_stmt = $pdo->prepare("
                INSERT INTO notifications (user_id, student_id, message, is_read, created_at)
                VALUES (0, :student_id, :message, 0, NOW())
            ");
            $message = "Your retrieval request for item '" . $request['item_name'] . "' has been approved.";
            $notif_stmt->execute([
                'student_id' => $request['student_id'],
                'message'    => $message
            ]);
            
            $pdo->commit();
            echo "Retrieval request approved successfully!";
        } catch (Exception $e) {
            $pdo->rollBack();
            echo "Error approving retrieval request: " . $e->getMessage();
        }
        exit();
    }

    // Handle retrieval request rejection
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reject_retrieve_id'])) {
        $requestId = $_POST['reject_retrieve_id'];
        try {
            // Start transaction
            $pdo->beginTransaction();
            
            // Get request details first
            $stmt = $pdo->prepare("SELECT item_id FROM retrieval_requests WHERE id = ?");
            $stmt->execute([$requestId]);
            $request = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($request) {
                // Update inventory quantity (restore it since request is rejected)
                $stmt = $pdo->prepare("UPDATE inventory_items SET quantity = quantity + 1 WHERE id = ?");
                $stmt->execute([$request['item_id']]);
            }
            
            // Update retrieval request status
            $stmt = $pdo->prepare("UPDATE retrieval_requests SET status = 'rejected' WHERE id = ?");
            $stmt->execute([$requestId]);
            
            // Get request details for notification
            $stmt = $pdo->prepare("
                SELECT rr.student_id, rr.item_id, i.name as item_name
                FROM retrieval_requests rr
                LEFT JOIN inventory_items i ON rr.item_id = i.id
                WHERE rr.id = ?
            ");
            $stmt->execute([$requestId]);
            $request = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Add notification
            if ($request) {
                $notif_stmt = $pdo->prepare("
                    INSERT INTO notifications (user_id, student_id, message, is_read, created_at)
                    VALUES (0, :student_id, :message, 0, NOW())
                ");
                $message = "Your retrieval request for item '" . $request['item_name'] . "' has been rejected.";
                $notif_stmt->execute([
                    'student_id' => $request['student_id'],
                    'message'    => $message
                ]);
            }
            
            $pdo->commit();
            echo "Retrieval request rejected successfully!";
        } catch (Exception $e) {
            $pdo->rollBack();
            echo "Error rejecting retrieval request: " . $e->getMessage();
        }
        exit();
    }

} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SIMS</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #ecf0f1;
            color: #2c3e50;
            margin: 0;
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            position: fixed;
            height: 100vh;
            top: 0;
            left: 0;
            transition: transform 0.3s ease-in-out;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #1abc9c;
            font-size: 24px;
            padding-bottom: 15px;
            border-bottom: 2px solid #1abc9c;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            margin-bottom: 5px;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
        }
        .sidebar ul li a:hover {
            background-color: #1abc9c;
            transform: translateX(5px);
        }
        .sidebar ul li a.active {
            background-color: #1abc9c;
            color: white;
        }
        .sidebar ul li a i {
            margin-right: 10px;
            font-size: 18px;
        }
        .content {
            margin-left: 270px;
            padding: 20px;
            width: calc(100% - 270px);
        }
        .container {
            background: white;
            padding: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 50px;
            padding: 30px 40px;
            background-color: #fff;
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            position: relative;
            z-index: 10;
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
        }
        .dashboard-header h2 {
            color: #2c3e50;
            font-size: 24px;
            margin: 0;
        }

        /* Search Bar Styles */
        .search-bar {
            position: relative;
            width: 400px;
            max-width: 70%;
            margin-left: auto;
            margin-right: 40px;
        }

        .search-input {
            width: 100%;
            padding: 15px 45px 15px 20px;
            border: 2px solid #e1e8ed;
            border-radius: 25px;
            font-size: 16px;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s ease;
            background-color: #fff;
        }

        .search-input::placeholder {
            color: #8e8e93;
        }

        .search-input:focus {
            outline: none;
            border-color: #3498db;
            box-shadow: 0 0 0 4px rgba(52, 152, 219, 0.15);
            background-color: #fff;
        }

        .search-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #8e8e93;
            font-size: 18px;
            transition: all 0.3s ease;
        }

        .search-input:focus + .search-icon {
            color: #3498db;
        }
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-card h3 {
            color: #2c3e50;
            margin: 0 0 10px 0;
            font-size: 18px;
            display: flex;
            align-items: center;
        }
        .stat-card h3 i {
            margin-right: 10px;
            color: #1abc9c;
        }
        .stat-card .count {
            font-size: 24px;
            font-weight: 600;
            color: #1abc9c;
        }
        .section-title {
            color: #2c3e50;
            font-size: 20px;
            margin: 30px 0 20px 0;
            padding-bottom: 10px;
            border-bottom: 2px solid #1abc9c;
            display: flex;
            align-items: center;
        }
        .section-title i {
            margin-right: 10px;
            color: #1abc9c;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #1abc9c;
            color: white;
            font-weight: 600;
        }
        tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        tr:hover {
            background-color: #d1f2eb;
        }
        .button-group {
            display: flex;
            gap: 10px;
        }
        button {
            background: #1abc9c;
            color: white;
            border: none;
            padding: 8px 15px;
            cursor: pointer;
            border-radius: 5px;
            transition: all 0.3s ease;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        button:hover {
            background: #16a085;
            transform: scale(1.05);
        }
        button.reject {
            background: #e74c3c;
        }
        button.reject:hover {
            background: #c0392b;
        }
        .logout {
            background: #e74c3c;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            color: white;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }

        .logout:hover {
            background: #c0392b;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            font-weight: 500;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .empty-message {
            text-align: center;
            padding: 20px;
            color: #666;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Admin Menu</h2>
        <ul>
        <li><a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="Manage_request.php"><i class="fas fa-tasks"></i> Manage Requests</a></li>
            <li><a href="CRUD.php"><i class="fas fa-box"></i> Manage Products</a></li>
            <li><a href="admin_monitoring.php"><i class="fas fa-desktop"></i> System Monitoring</a></li>
            <li><a href="Approve.php"><i class="fas fa-user-graduate"></i> Students</a></li>
            <li><a href="Records.php"><i class="fas fa-history"></i> Records</a></li>
        </ul>
        <form action="logout.php" method="POST" style="display: inline;">
            <button type="submit" class="logout"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
    </div>

    <div class="content">
        <div class="container">
            <div class="dashboard-header">
                <h2><i class="fas fa-tachometer-alt"></i> Admin Dashboard</h2>
                <div class="search-bar">
                    <input type="text" id="searchInput" class="search-input" placeholder="Search requests..." onkeyup="filterRequests()">
                    <i class="fas fa-search search-icon"></i>
                </div>
            </div>

            <script>
                function filterRequests() {
                    const input = document.getElementById('searchInput');
                    const filter = input.value.toUpperCase();
                    
                    // Filter all tables
                    document.querySelectorAll('table').forEach(table => {
                        const tr = table.getElementsByTagName('tr');
                        
                        for (let i = 1; i < tr.length; i++) {
                            let match = false;
                            const td = tr[i].getElementsByTagName('td');
                            
                            for (let j = 0; j < td.length; j++) {
                                if (td[j]) {
                                    const txtValue = td[j].textContent || td[j].innerText;
                                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                                        match = true;
                                        break;
                                    }
                                }
                            }
                            
                            tr[i].style.display = match ? '' : 'none';
                        }
                    });
                }
            </script>

            <!-- Pending Inventory Items -->
            <h3 class="section-title"><i class="fas fa-box"></i> Pending Inventory Items</h3>
            <table>
                <thead>
                    <tr>
                        <th>Item ID</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Condition</th>
                        <th>Quantity</th>
                        <th>Reason</th>
                        <th>Image</th>
                        <th>Added</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($pendingInventory)): ?>
                        <?php foreach ($pendingInventory as $item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['id']); ?></td>
                                <td><?php echo htmlspecialchars($item['name']); ?></td>
                                <td><?php echo htmlspecialchars($item['category']); ?></td>
                                <td><?php echo htmlspecialchars($item['item_condition']); ?></td>
                                <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                                <td><?php echo htmlspecialchars($item['description']); ?></td>
                                <td>
                                    <?php if (!empty($item['image_url'])): ?>
                                        <img src="<?php echo htmlspecialchars($item['image_url']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" style="max-width:60px; max-height:60px; border-radius:5px;">
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($item['created_at']); ?></td>
                                <td>
                                    <div class="button-group">
                                        <button class="approve-inventory" data-id="<?php echo $item['id']; ?>">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button class="reject reject-inventory" data-id="<?php echo $item['id']; ?>">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="9" class="empty-message">No pending inventory items.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <h3 class="section-title"><i class="fas fa-hand-holding"></i> Pending Borrow Requests</h3>
            <table>
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>Student ID</th>
                        <th>Product Name</th>
                        <th>Product ID</th>
                        <th>Barcode</th>
                        <th>Due Date</th>
                        <th>Status</th>
                        <th>Request Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($pendingRequests)): ?>
                        <?php foreach ($pendingRequests as $request): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($request['request_id']); ?></td>
                                <td><?php echo htmlspecialchars($request['student_id']); ?></td>
                                <td><?php echo htmlspecialchars($request['product_name']); ?></td>
                                <td><?php echo htmlspecialchars($request['product_id']); ?></td>
                                <td><?php echo htmlspecialchars($request['barcode']); ?></td>
                                <td><?php echo htmlspecialchars($request['due_date']); ?></td>
                                <td><?php echo htmlspecialchars($request['status']); ?></td>
                                <td><?php echo htmlspecialchars($request['request_date']); ?></td>
                                <td>
                                    <div class="button-group">
                                        <button class="approve-request" data-id="<?php echo $request['request_id']; ?>">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button class="reject reject-request" data-id="<?php echo $request['request_id']; ?>">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="9" class="empty-message">No pending borrow requests.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- Pending Return Requests -->
            <h3 class="section-title"><i class="fas fa-undo"></i> Pending Return Requests</h3>
            <table>
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>Student ID</th>
                        <th>Product Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($pendingReturns)): ?>
                        <?php foreach ($pendingReturns as $return): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($return['request_id']); ?></td>
                                <td><?php echo htmlspecialchars($return['student_id']); ?></td>
                                <td><?php echo htmlspecialchars($return['product_name']); ?></td>
                                <td>
                                    <div class="button-group">
                                        <button class="approve-return" data-id="<?php echo $return['request_id']; ?>">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button class="reject reject-return" data-id="<?php echo $return['request_id']; ?>">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="4" class="empty-message">No pending return requests.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- Pending Retrieve Requests -->
            <h3 class="section-title"><i class="fas fa-hand-holding"></i> Pending Retrieve Requests</h3>
            <table>
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>Student ID</th>
                        <th>Item Name</th>
                        <th>Request Date</th>
                        <th>Reason</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($pendingRetrieves)): ?>
                        <?php foreach ($pendingRetrieves as $retrieve): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($retrieve['request_id']); ?></td>
                                <td><?php echo htmlspecialchars($retrieve['student_id']); ?></td>
                                <td><?php echo htmlspecialchars($retrieve['item_name']); ?></td>
                                <td><?php echo htmlspecialchars($retrieve['request_date']); ?></td>
                                <td><?php echo htmlspecialchars($retrieve['reason']); ?></td>
                                <td>
                                    <div class="button-group">
                                        <button class="approve-retrieve" data-id="<?php echo $retrieve['request_id']; ?>">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button class="reject reject-retrieve" data-id="<?php echo $retrieve['request_id']; ?>">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="empty-message">No pending retrieve requests.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

        <script>
            $(document).ready(function () {
                // Function to update all tables
                function updateTables() {
                    $.ajax({
                        url: 'get_pending_data.php',
                        method: 'GET',
                        success: function(response) {
                            const data = JSON.parse(response);
                            
                            // Update stats
                            $('.stat-card:nth-child(1) .count').text(data.pendingInventory.length);
                            $('.stat-card:nth-child(2) .count').text(data.pendingRequests.length);
                            $('.stat-card:nth-child(3) .count').text(data.pendingReturns.length);

                            // Update Inventory Table
                            updateInventoryTable(data.pendingInventory);
                            
                            // Update Borrow Requests Table
                            updateBorrowRequestsTable(data.pendingRequests);
                            
                            // Update Return Requests Table
                            updateReturnRequestsTable(data.pendingReturns);
                            
                            // Update Retrieve Requests Table
                            updateRetrieveRequestsTable(data.pendingRetrieves);
                        },
                        error: function() {
                            console.error('Error fetching updates');
                        }
                    });
                }

                // Function to update inventory table
                function updateInventoryTable(items) {
                    const tbody = $('table:eq(0) tbody');
                    tbody.empty();
                    
                    if (items.length === 0) {
                        tbody.append('<tr><td colspan="9" class="empty-message">No pending inventory items.</td></tr>');
                        return;
                    }

                    items.forEach(item => {
                        const row = `
                            <tr>
                                <td>${item.id}</td>
                                <td>${item.name}</td>
                                <td>${item.category}</td>
                                <td>${item.item_condition}</td>
                                <td>${item.quantity}</td>
                                <td>${item.description}</td>
                                <td>${item.image_url ? `<img src="${item.image_url}" alt="${item.name}" style="max-width:60px; max-height:60px; border-radius:5px;">` : ''}</td>
                                <td>${item.created_at}</td>
                                <td>
                                    <div class="button-group">
                                        <button class="approve-inventory" data-id="${item.id}">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button class="reject reject-inventory" data-id="${item.id}">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `;
                        tbody.append(row);
                    });
                }

                // Function to update borrow requests table
                function updateBorrowRequestsTable(requests) {
                    const tbody = $('table:eq(1) tbody');
                    tbody.empty();
                    
                    if (requests.length === 0) {
                        tbody.append('<tr><td colspan="9" class="empty-message">No pending borrow requests.</td></tr>');
                        return;
                    }

                    requests.forEach(request => {
                        const row = `
                            <tr>
                                <td>${request.request_id}</td>
                                <td>${request.student_name}</td>
                                <td>${request.product_name}</td>
                                <td>${request.product_id}</td>
                                <td>${request.barcode}</td>
                                <td>${request.due_date}</td>
                                <td>${request.status}</td>
                                <td>${request.request_date}</td>
                                <td>
                                    <div class="button-group">
                                        <button class="approve-request" data-id="${request.request_id}">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button class="reject reject-request" data-id="${request.request_id}">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `;
                        tbody.append(row);
                    });
                }

                // Function to update return requests table
                function updateReturnRequestsTable(returns) {
                    const tbody = $('table:eq(2) tbody');
                    tbody.empty();
                    
                    if (returns.length === 0) {
                        tbody.append('<tr><td colspan="4" class="empty-message">No pending return requests.</td></tr>');
                        return;
                    }

                    returns.forEach(return_req => {
                        const row = `
                            <tr>
                                <td>${return_req.request_id}</td>
                                <td>${return_req.student_name}</td>
                                <td>${return_req.product_name}</td>
                                <td>
                                    <div class="button-group">
                                        <button class="approve-return" data-id="${return_req.request_id}">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button class="reject reject-return" data-id="${return_req.request_id}">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `;
                        tbody.append(row);
                    });
                }

                // Function to update retrieve requests table
                function updateRetrieveRequestsTable(retrieves) {
                    const tbody = $('table:eq(3) tbody');
                    tbody.empty();
                    
                    if (retrieves.length === 0) {
                        tbody.append('<tr><td colspan="6" class="empty-message">No pending retrieve requests.</td></tr>');
                        return;
                    }

                    retrieves.forEach(retrieve => {
                        const row = `
                            <tr>
                                <td>${retrieve.request_id}</td>
                                <td>${retrieve.student_name}</td>
                                <td>${retrieve.item_name}</td>
                                <td>${retrieve.request_date}</td>
                                <td>${retrieve.reason}</td>
                                <td>
                                    <div class="button-group">
                                        <button class="approve-retrieve" data-id="${retrieve.request_id}">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button class="reject reject-retrieve" data-id="${retrieve.request_id}">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `;
                        tbody.append(row);
                    });
                }

                // Start polling every 5 seconds
                setInterval(updateTables, 5000);

                // Initial update
                updateTables();

                // Event delegation for dynamically added buttons
                $(document).on('click', '.approve-inventory', function() {
                    let itemId = $(this).data("id");
                    if (!confirm("Are you sure you want to approve this inventory item?")) return;

                    $.post("manage_request.php", { 
                        approve_inventory_id: itemId
                    }, function(response) {
                        alert(response);
                        updateTables();
                    }).fail(function() {
                        alert("Error approving inventory item.");
                    });
                });

                $(document).on('click', '.reject-inventory', function() {
                    let itemId = $(this).data("id");
                    if (!confirm("Are you sure you want to reject this inventory item?")) return;

                    $.post("manage_request.php", { 
                        reject_inventory_id: itemId
                    }, function(response) {
                        alert(response);
                        updateTables();
                    }).fail(function() {
                        alert("Error rejecting inventory item.");
                    });
                });

                $(document).on('click', '.approve-request', function() {
                    let requestId = $(this).data("id");
                    let studentName = $(this).closest('tr').find('td:eq(1)').text();
                    let productName = $(this).closest('tr').find('td:eq(2)').text();

                    if (!confirm("Are you sure you want to approve this borrow request?")) return;

                    $.post("approve_request.php", { 
                        request_id: requestId,
                        student_name: studentName,
                        product_name: productName
                    }, function(response) {
                        alert(response);
                        updateTables();
                    }).fail(function() {
                        alert("Error approving request.");
                    });
                });

                $(document).on('click', '.reject-request', function() {
                    let requestId = $(this).data("id");
                    let studentName = $(this).closest('tr').find('td:eq(1)').text();
                    let productName = $(this).closest('tr').find('td:eq(2)').text();

                    if (!confirm("Are you sure you want to reject this borrow request?")) return;

                    $.post("reject_request.php", { 
                        request_id: requestId,
                        student_name: studentName,
                        product_name: productName
                    }, function(response) {
                        alert(response);
                        updateTables();
                    }).fail(function() {
                        alert("Error rejecting request.");
                    });
                });

                $(document).on('click', '.approve-return', function() {
                    let requestId = $(this).data("id");
                    let studentName = $(this).closest('tr').find('td:eq(1)').text();
                    let productName = $(this).closest('tr').find('td:eq(2)').text();

                    if (!confirm("Are you sure you want to approve this return request?")) return;

                    $.post("approve_return.php", { 
                        request_id: requestId,
                        student_name: studentName,
                        product_name: productName
                    }, function(response) {
                        alert(response);
                        updateTables();
                    }).fail(function() {
                        alert("Error approving return.");
                    });
                });

                $(document).on('click', '.approve-retrieve', function() {
                    let requestId = $(this).data("id");
                    if (!confirm("Are you sure you want to approve this retrieve request?")) return;
                    
                    $.post("manage_request.php", { 
                        approve_retrieve_id: requestId
                    }, function(response) {
                        alert(response);
                        updateTables();
                    }).fail(function() {
                        alert("Error approving retrieve request.");
                    });
                });

                $(document).on('click', '.reject-retrieve', function() {
                    let requestId = $(this).data("id");
                    if (!confirm("Are you sure you want to reject this retrieve request?")) return;
                    
                    $.post("manage_request.php", { 
                        reject_retrieve_id: requestId
                    }, function(response) {
                        alert(response);
                        updateTables();
                    }).fail(function() {
                        alert("Error rejecting retrieve request.");
                    });
                });

                $(document).on('click', '.reject-return', function() {
                    let requestId = $(this).data("id");
                    let studentName = $(this).closest('tr').find('td:eq(1)').text();
                    let productName = $(this).closest('tr').find('td:eq(2)').text();

                    if (!confirm("Are you sure you want to reject this return request?")) return;

                    $.post("reject_return.php", { 
                        request_id: requestId,
                        student_name: studentName,
                        product_name: productName
                    }, function(response) {
                        alert(response);
                        updateTables();
                    }).fail(function() {
                        alert("Error rejecting return.");
                    });
                });
            });
        </script>
</body>
</html>