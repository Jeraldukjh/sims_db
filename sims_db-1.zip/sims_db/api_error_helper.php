<?php
function log_api_error($message, $context = []) {
    $errorData = [
        'timestamp' => date('Y-m-d H:i:s'),
        'error' => $message,
        'context' => $context,
        'endpoint' => $_SERVER['REQUEST_URI'],
        'ip' => $_SERVER['REMOTE_ADDR']
    ];
    file_put_contents('api_errors.log', json_encode($errorData) . PHP_EOL, FILE_APPEND);
} 