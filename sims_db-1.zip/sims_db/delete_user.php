<?php
require_once __DIR__ . '/db.php';
header('Content-Type: application/json');

// Get the token from the Authorization header
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;

if (!$token) {
    http_response_code(401);
    echo json_encode([
        "status" => "error",
        "message" => "No token provided"
    ]);
    exit();
}

try {
    $stmt = $pdo->prepare("SELECT id, is_admin FROM users WHERE token = :token AND is_admin = 1");
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        http_response_code(401);
        echo json_encode([
            "status" => "error",
            "message" => "Invalid or expired token"
        ]);
        exit();
    }

    // Get DELETE data
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['student_id'])) {
        http_response_code(400);
        echo json_encode([
            "status" => "error",
            "message" => "Student ID is required"
        ]);
        exit();
    }

    $student_id = $data['student_id'];

    // Start transaction
    $pdo->beginTransaction();

    try {
        // Check if user exists and is not the last admin
        $stmt = $pdo->prepare("
            SELECT id, is_admin 
            FROM users 
            WHERE student_id = :student_id
            FOR UPDATE
        ");
        $stmt->bindParam(':student_id', $student_id);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            throw new Exception("User not found");
        }

        // Check if trying to delete the last admin
        if ($user['is_admin']) {
            $stmt = $pdo->prepare("SELECT COUNT(*) as admin_count FROM users WHERE is_admin = 1");
            $stmt->execute();
            $adminCount = $stmt->fetch(PDO::FETCH_ASSOC)['admin_count'];

            if ($adminCount <= 1) {
                throw new Exception("Cannot delete the last admin user");
            }
        }

        // Delete related records first
        // Delete notifications
        $stmt = $pdo->prepare("DELETE FROM notifications WHERE student_id = :student_id");
        $stmt->bindParam(':student_id', $student_id);
        $stmt->execute();

        // Delete borrow requests
        $stmt = $pdo->prepare("DELETE FROM borrow_requests WHERE student_id = :student_id");
        $stmt->bindParam(':student_id', $student_id);
        $stmt->execute();

        // Delete user
        $stmt = $pdo->prepare("DELETE FROM users WHERE student_id = :student_id");
        $stmt->bindParam(':student_id', $student_id);
        $stmt->execute();

        $pdo->commit();
        
        echo json_encode([
            "status" => "success",
            "message" => "User deleted successfully"
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => $e->getMessage()
    ]);
}
?> 