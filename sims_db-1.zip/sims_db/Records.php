<?php
require_once 'db.php';
session_start(); // Ensure the session is started

// Fetch all borrow requests
$stmt = $pdo->prepare("SELECT borrow_requests.request_id, borrow_requests.student_id, borrow_requests.product_id, borrow_requests.barcode, borrow_requests.due_date, 
    CASE 
        WHEN return_requests.status = 'approved' THEN 'Returned'
        ELSE borrow_requests.status 
    END as status,
    borrow_requests.request_date, users.name, products.product_name 
    FROM borrow_requests 
    JOIN users ON borrow_requests.student_id = users.student_id
    JOIN products ON borrow_requests.product_id = products.product_id
    LEFT JOIN return_requests ON borrow_requests.request_id = return_requests.request_id");
$stmt->execute();
$borrowedItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch all retrieval requests
$stmt = $pdo->prepare("
    SELECT rr.id as request_id, rr.reason, rr.preferred_date, rr.created_at as request_date,
           rr.status, u.name as student_name, u.student_id, i.name as item_name
    FROM retrieval_requests rr
    JOIN users u ON rr.student_id = u.student_id
    JOIN inventory_items i ON rr.item_id = i.id
    ORDER BY rr.created_at DESC
");
$stmt->execute();
$retrievalItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch inventory history
$stmt = $pdo->prepare("
    SELECT id, name, description, quantity, category, item_condition, 
           status, student_id, created_at, image_url
    FROM inventory_items
    ORDER BY created_at DESC
");
$stmt->execute();
$inventoryHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Records</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #ecf0f1;
            color: #2c3e50;
            margin: 0;
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            position: fixed;
            height: 100vh;
            top: 0;
            left: 0;
            transition: transform 0.3s ease-in-out;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #1abc9c;
            font-size: 24px;
            padding-bottom: 15px;
            border-bottom: 2px solid #1abc9c;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            margin-bottom: 5px;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
        }
        .sidebar ul li a:hover {
            background-color: #1abc9c;
            transform: translateX(5px);
        }
        .sidebar ul li a.active {
            background-color: #1abc9c;
            color: white;
        }
        .sidebar ul li a i {
            margin-right: 10px;
            font-size: 18px;
        }
        .content {
            margin-left: 270px;
            padding: 20px;
            width: calc(100% - 270px);
        }
        .container {
            background: white;
            padding: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #1abc9c;
            color: white;
            font-weight: 600;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #d1f2eb;
        }
        .status-approved {
            color: #27ae60;
            font-weight: bold;
        }
        .status-declined, .status-rejected {
            color: #e74c3c;
            font-weight: bold;
        }
        .status-returned {
            color: #8a2be2;
            font-weight: bold;
        }
        button {
            background: #1abc9c;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 5px;
            transition: background 0.3s ease, transform 0.2s ease;
            font-weight: 600;
        }
        button:hover {
            background: #16a085;
            transform: scale(1.05);
        }
        .logout {
            background: #e74c3c;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            color: white;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }

        .logout:hover {
            background: #c0392b;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Admin Menu</h2>
        <ul>
        <li><a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="Manage_request.php"><i class="fas fa-tasks"></i> Manage Requests</a></li>
            <li><a href="CRUD.php"><i class="fas fa-box"></i> Manage Products</a></li>
            <li><a href="admin_monitoring.php"><i class="fas fa-desktop"></i> System Monitoring</a></li>
            <li><a href="Approve.php"><i class="fas fa-user-graduate"></i> Students</a></li>
            <li><a href="Records.php"><i class="fas fa-history"></i> Records</a></li>
        </ul>
        <form action="logout.php" method="POST" style="display: inline;">
            <button type="submit" class="logout"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
    </div>
    <div class="content">
        <div class="container">
            <div class="search-container">
                <input type="text" id="searchInput" placeholder="Search by student name, product name, or request ID..." class="search-input">
                <select id="searchType" class="search-select">
                    <option value="all">All Records</option>
                    <option value="borrow">Borrow Requests</option>
                    <option value="retrieval">Retrieval Requests</option>
                    <option value="inventory">Inventory History</option>
                </select>
            </div>

            <style>
                .search-container {
                    display: flex;
                    gap: 10px;
                    margin-bottom: 20px;
                }
                .search-input {
                    flex: 1;
                    padding: 10px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    font-size: 14px;
                }
                .search-select {
                    padding: 10px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    font-size: 14px;
                }
            </style>

            <script>
                $(document).ready(function() {
                    $('#searchInput').on('keyup', function() {
                        const value = $(this).val().toLowerCase();
                        const type = $('#searchType').val();
                        
                        $('#borrowTable tbody tr').show();
                        $('#retrievalTable tbody tr').show();
                        $('#inventoryTable tbody tr').show();
                        
                        if (type !== 'all') {
                            if (type === 'borrow') {
                                $('#retrievalTable tbody tr').hide();
                                $('#inventoryTable tbody tr').hide();
                            } else if (type === 'retrieval') {
                                $('#borrowTable tbody tr').hide();
                                $('#inventoryTable tbody tr').hide();
                            } else if (type === 'inventory') {
                                $('#borrowTable tbody tr').hide();
                                $('#retrievalTable tbody tr').hide();
                            }
                        }
                        
                        // Filter based on search term
                        if (value) {
                            $('#borrowTable tbody tr').each(function() {
                                if (type === 'all' || type === 'borrow') {
                                    const match = $(this).text().toLowerCase().indexOf(value) > -1;
                                    $(this).toggle(match);
                                }
                            });

                            $('#retrievalTable tbody tr').each(function() {
                                if (type === 'all' || type === 'retrieval') {
                                    const match = $(this).text().toLowerCase().indexOf(value) > -1;
                                    $(this).toggle(match);
                                }
                            });

                            $('#inventoryTable tbody tr').each(function() {
                                if (type === 'all' || type === 'inventory') {
                                    const match = $(this).text().toLowerCase().indexOf(value) > -1;
                                    $(this).toggle(match);
                                }
                            });
                        }
                    });

                    $('#searchType').on('change', function() {
                        $('#searchInput').trigger('keyup');
                    });
                });
            </script>

            <style>
                .search-container {
                    display: flex;
                    gap: 10px;
                    margin-bottom: 20px;
                }
                .search-input {
                    flex: 1;
                    padding: 10px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    font-size: 14px;
                }
                .search-select {
                    padding: 10px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    font-size: 14px;
                }
            </style>

            <script>
                $(document).ready(function() {
                    $('#searchInput').on('keyup', function() {
                        const value = $(this).val().toLowerCase();
                        const type = $('#searchType').val();
                        
                        // Filter borrow requests
                        $('table#borrowTable tr').each(function() {
                            if (type === 'all' || type === 'borrow') {
                                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
                            } else {
                                $(this).hide();
                            }
                        });

                        // Filter retrieval requests
                        $('table#retrievalTable tr').each(function() {
                            if (type === 'all' || type === 'retrieval') {
                                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
                            } else {
                                $(this).hide();
                            }
                        });

                        // Filter inventory history
                        $('table#inventoryTable tr').each(function() {
                            if (type === 'all' || type === 'inventory') {
                                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
                            } else {
                                $(this).hide();
                            }
                        });
                    });

                    $('#searchType').on('change', function() {
                        $('#searchInput').trigger('keyup');
                    });
                });
            </script>
            <h2>Borrowed Items</h2>
            <table id="borrowTable">
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>Student Name</th>
                        <th>Student ID</th>
                        <th>Product Name</th>
                        <th>Barcode</th>
                        <th>Due Date</th>
                        <th>Status</th>
                        <th>Request Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($borrowedItems as $item): ?>
                    <tr>
                        <td><?= htmlspecialchars($item['request_id']); ?></td>
                        <td><?= htmlspecialchars($item['name']); ?></td>
                        <td><?= htmlspecialchars($item['student_id']); ?></td>
                        <td><?= htmlspecialchars($item['product_name']); ?></td>
                        <td><?= htmlspecialchars($item['barcode']); ?></td>
                        <td><?= htmlspecialchars($item['due_date']); ?></td>
                        <td class="status-<?= strtolower($item['status']); ?>"><?= htmlspecialchars($item['status']); ?></td>
                        <td><?= htmlspecialchars($item['request_date']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <h2 style="margin-top: 40px;">Retrieval Requests</h2>
            <table id="retrievalTable">
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>Student Name</th>
                        <th>Student ID</th>
                        <th>Item Name</th>
                        <th>Preferred Date</th>
                        <th>Reason</th>
                        <th>Status</th>
                        <th>Request Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($retrievalItems as $item): ?>
                    <tr>
                        <td><?= htmlspecialchars($item['request_id']); ?></td>
                        <td><?= htmlspecialchars($item['student_name']); ?></td>
                        <td><?= htmlspecialchars($item['student_id']); ?></td>
                        <td><?= htmlspecialchars($item['item_name']); ?></td>
                        <td><?= htmlspecialchars($item['preferred_date']); ?></td>
                        <td><?= htmlspecialchars($item['reason']); ?></td>
                        <td class="status-<?= strtolower($item['status']); ?>"><?= htmlspecialchars($item['status']); ?></td>
                        <td><?= htmlspecialchars($item['request_date']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <h2 style="margin-top: 40px;">Inventory History</h2>
            <table id="inventoryTable">
                <thead>
                    <tr>
                        <th>Item ID</th>
                        <th>Student ID</th>
                        <th>Item Name</th>
                        <th>Description</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Condition</th>
                        <th>Status</th>
                        <th>Image</th>
                        <th>Date Added</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($inventoryHistory as $item): ?>
                    <tr>
                        <td><?= htmlspecialchars($item['id']); ?></td>
                        <td><?= htmlspecialchars($item['student_id']); ?></td>
                        <td><?= htmlspecialchars($item['name']); ?></td>
                        <td><?= htmlspecialchars($item['description']); ?></td>
                        <td><?= htmlspecialchars($item['category']); ?></td>
                        <td><?= htmlspecialchars($item['quantity']); ?></td>
                        <td><?= htmlspecialchars($item['item_condition']); ?></td>
                        <td class="status-<?= strtolower($item['status']); ?>"><?= htmlspecialchars($item['status']); ?></td>
                        <td>
                            <?php if (!empty($item['image_url'])): ?>
                                <img src="<?= htmlspecialchars($item['image_url']); ?>" alt="Item Image" style="max-width: 50px; max-height: 50px;">
                            <?php else: ?>
                                No Image
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($item['created_at']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
