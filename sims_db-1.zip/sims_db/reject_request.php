<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['is_admin'])) {
    die("Unauthorized access");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_id'])) {
    try {
        $requestId = $_POST['request_id'];
        $studentName = $_POST['student_name'];
        $productName = $_POST['product_name'];

        // Get student_id from the request
        $stmt = $pdo->prepare("SELECT student_id FROM borrow_requests WHERE request_id = ?");
        $stmt->execute([$requestId]);
        $studentId = $stmt->fetchColumn();

        if ($studentId) {
            // Get product details
            $stmt = $pdo->prepare("SELECT product_id FROM borrow_requests WHERE request_id = ?");
            $stmt->execute([$requestId]);
            $productId = $stmt->fetchColumn();
            
            if ($productId) {
                // Restore inventory stock since request is rejected
                $stmt = $pdo->prepare("UPDATE products SET stock = stock + 1 WHERE product_id = ?");
                $stmt->execute([$productId]);
            }
            
            // Update the request status
            $stmt = $pdo->prepare("UPDATE borrow_requests SET status = 'rejected' WHERE request_id = ?");
            $stmt->execute([$requestId]);

            // Send notification
            $message = "Your borrow request for {$productName} has been rejected.";
            $stmt = $pdo->prepare("INSERT INTO notifications (user_id, student_id, message, is_read, created_at) VALUES (?, ?, ?, 0, NOW())");
            $stmt->execute([0, $studentId, $message]);

            echo "Request rejected successfully!";
        } else {
            echo "Error: Student ID not found.";
        }
    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
    }
} else {
    echo "Invalid request.";
}
?>
