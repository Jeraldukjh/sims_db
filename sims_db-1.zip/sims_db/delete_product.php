<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/api_error_response.php';
header('Content-Type: application/json');

// Get the token from the Authorization header
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;

if (!$token) {
    api_error_response('No token provided', 401, ['endpoint' => $_SERVER['PHP_SELF']]);
}

try {
    $stmt = $pdo->prepare("SELECT id, is_admin FROM users WHERE token = :token AND is_admin = 1");
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        api_error_response('Invalid or expired token', 401, ['endpoint' => $_SERVER['PHP_SELF']]);
    }

    // Get DELETE data
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['product_id'])) {
        api_error_response('Product ID is required', 400, array_merge($data, ['endpoint' => $_SERVER['PHP_SELF']]));
    }

    // Check if product exists
    $stmt = $pdo->prepare("SELECT product_id FROM products WHERE product_id = :product_id");
    $stmt->bindParam(':product_id', $data['product_id']);
    $stmt->execute();
    
    if ($stmt->rowCount() === 0) {
        api_error_response('Product not found', 404, array_merge($data, ['endpoint' => $_SERVER['PHP_SELF']]));
    }

    // Delete product
    $stmt = $pdo->prepare("DELETE FROM products WHERE product_id = :product_id");
    $stmt->bindParam(':product_id', $data['product_id']);
    $stmt->execute();
    
    echo json_encode([
        "status" => "success",
        "message" => "Product deleted successfully"
    ]);
    
} catch (PDOException $e) {
    api_error_response('Database error: ' . $e->getMessage(), 500, array_merge($data ?? [], ['endpoint' => $_SERVER['PHP_SELF']]));
}
?> 