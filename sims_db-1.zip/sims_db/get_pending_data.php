<?php
session_start();
require_once __DIR__ . '/db.php';

// Ensure the user is logged in as admin
if (!isset($_SESSION['is_admin'])) {
    header('HTTP/1.1 403 Forbidden');
    exit('Unauthorized');
}

if (!isset($pdo)) {
    header('HTTP/1.1 500 Internal Server Error');
    exit('Database connection failed');
}

try {
    // Fetch pending borrow requests with student and product details
    $stmt = $pdo->prepare("
        SELECT br.request_id, br.product_id, br.barcode, br.due_date, br.status, br.request_date, COALESCE(u.name, 'Unknown') AS student_name, p.product_name 
        FROM borrow_requests br
        LEFT JOIN users u ON br.student_id = u.student_id
        LEFT JOIN products p ON br.product_id = p.product_id
        WHERE br.status = 'pending'
    ");
    $stmt->execute();
    $pendingRequests = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch pending return requests with student and product details
    $stmt = $pdo->prepare("
        SELECT rr.request_id, COALESCE(u.name, 'Unknown') AS student_name, p.product_name 
        FROM return_requests rr
        LEFT JOIN users u ON rr.student_id = u.student_id
        LEFT JOIN products p ON rr.product_id = p.product_id
        WHERE rr.status = 'pending'
    ");
    $stmt->execute();
    $pendingReturns = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch pending inventory items
    $stmt = $pdo->prepare("
        SELECT id, name, description, quantity, category, item_condition, image_url, created_at
        FROM inventory_items
        WHERE status = 'pending'
        ORDER BY created_at DESC
    ");
    $stmt->execute();
    $pendingInventory = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch pending retrieval requests
    $stmt = $pdo->prepare("
        SELECT rr.id as request_id, rr.reason, rr.preferred_date, rr.created_at as request_date,
               u.name as student_name, i.name as item_name
        FROM retrieval_requests rr
        JOIN users u ON rr.user_id = u.id
        JOIN inventory_items i ON rr.item_id = i.id
        WHERE rr.status = 'pending'
        ORDER BY rr.created_at DESC
    ");
    $stmt->execute();
    $pendingRetrieves = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Return all data as JSON
    header('Content-Type: application/json');
    echo json_encode([
        'pendingRequests' => $pendingRequests,
        'pendingReturns' => $pendingReturns,
        'pendingInventory' => $pendingInventory,
        'pendingRetrieves' => $pendingRetrieves
    ]);

} catch (PDOException $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
} 