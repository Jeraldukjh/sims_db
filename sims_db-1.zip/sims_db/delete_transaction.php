<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/api_error_response.php';
header('Content-Type: application/json');

// Get the token from the Authorization header
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;

if (!$token) {
    api_error_response('No token provided', 401, ['endpoint' => $_SERVER['PHP_SELF']]);
}

try {
    $stmt = $pdo->prepare("SELECT id, is_admin FROM users WHERE token = :token AND is_admin = 1");
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        api_error_response('Invalid or expired token', 401, ['endpoint' => $_SERVER['PHP_SELF']]);
    }

    // Get DELETE data
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['request_id'])) {
        api_error_response('Request ID is required', 400, array_merge($data, ['endpoint' => $_SERVER['PHP_SELF']]));
    }

    // Start transaction
    $pdo->beginTransaction();

    try {
        // Get request details
        $stmt = $pdo->prepare("
            SELECT br.*, p.stock 
            FROM borrow_requests br 
            JOIN products p ON br.product_id = p.product_id 
            WHERE br.request_id = :request_id
            FOR UPDATE
        ");
        $stmt->bindParam(':request_id', $data['request_id']);
        $stmt->execute();
        $request = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$request) {
            throw new Exception("Request not found");
        }

        // If request was approved, return the item to stock
        if ($request['status'] === 'approved') {
            $stmt = $pdo->prepare("UPDATE products SET stock = stock + 1 WHERE product_id = :product_id");
            $stmt->bindParam(':product_id', $request['product_id']);
            $stmt->execute();
        }

        // Delete the request
        $stmt = $pdo->prepare("DELETE FROM borrow_requests WHERE request_id = :request_id");
        $stmt->bindParam(':request_id', $data['request_id']);
        $stmt->execute();

        $pdo->commit();
        
        echo json_encode([
            "status" => "success",
            "message" => "Request deleted successfully"
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    api_error_response($e->getMessage(), 500, array_merge($data ?? [], ['endpoint' => $_SERVER['PHP_SELF']]));
}
?> 