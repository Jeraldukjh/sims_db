<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/api_error_response.php';
header('Content-Type: application/json');

// Get the token from the Authorization header
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;

if (!$token) {
    api_error_response('No token provided', 401, ['endpoint' => $_SERVER['PHP_SELF']]);
}

try {
    $stmt = $pdo->prepare("SELECT id, is_admin FROM users WHERE token = :token AND is_admin = 1");
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        api_error_response('Invalid or expired token', 401, ['token' => $token, 'endpoint' => $_SERVER['PHP_SELF']]);
    }

    // Get all borrowed items
    $stmt = $pdo->prepare("
        SELECT 
            br.request_id,
            br.student_id,
            u.name as student_name,
            br.product_id,
            p.product_name,
            br.barcode,
            br.due_date,
            br.status,
            br.request_date
        FROM borrow_requests br
        LEFT JOIN users u ON br.student_id = u.student_id
        LEFT JOIN products p ON br.product_id = p.product_id
        ORDER BY br.request_date DESC
    ");
    $stmt->execute();
    $borrowed_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get all retrieval requests
    $stmt = $pdo->prepare("
        SELECT 
            rr.id as request_id,
            rr.reason,
            rr.preferred_date,
            rr.created_at as request_date,
            rr.status,
            u.name as student_name,
            u.student_id,
            i.name as item_name
        FROM retrieval_requests rr
        LEFT JOIN users u ON rr.student_id = u.student_id
        LEFT JOIN inventory_items i ON rr.item_id = i.id
        ORDER BY rr.created_at DESC
    ");
    $stmt->execute();
    $retrieval_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get inventory history
    $stmt = $pdo->prepare("
        SELECT id, name, description, quantity, category, item_condition, status, created_at, image_url
        FROM inventory_items
        ORDER BY created_at DESC
    ");
    $stmt->execute();
    $inventory_history = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "status" => "success",
        "data" => [
            "borrowed_items" => $borrowed_items,
            "retrieval_requests" => $retrieval_requests,
            "inventory_history" => $inventory_history
        ]
    ]);
    
} catch (PDOException $e) {
    api_error_response('Database error: ' . $e->getMessage(), 500, ['query' => 'SELECT * FROM transactions', 'endpoint' => $_SERVER['PHP_SELF']]);
}
?> 