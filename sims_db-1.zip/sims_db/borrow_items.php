<?php
// Display errors for debugging
if (isset($_GET['debug']) && $_GET['debug'] == '1') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Start session
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: home.php");
    exit();
}

require 'db.php'; // Ensure this file correctly initializes $pdo

// Get session data
$studentId = $_SESSION['student_id'];
$username = $_SESSION['username'] ?? 'User  ';
$isAdmin = $_SESSION['is_admin'] ?? false;

if (empty($studentId)) {
    die("Error: Session data missing. Please log in again.");
}

// Fetch available products with categories
$stmt = $pdo->query("SELECT product_id, product_name, stock, category, image_url FROM products WHERE stock > 0 AND category NOT IN ('Inventory', 'Consumables')");
$availableProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle category filter (Using prepared statement for security)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['category'])) {
    $category = trim($_POST['category']);
    
    $stmt = $pdo->prepare("SELECT * FROM products WHERE LOWER(TRIM(category)) = LOWER(TRIM(?))");
    $stmt->execute([$category]);
    
    $filteredProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($filteredProducts);
    exit();
}

// Handle borrow request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['borrow_item'])) {
    $productId = $_POST['product_id'];
    
    // Set due date to 1 day from now
    $dueDate = date('Y-m-d', strtotime('+1 day'));

    // Check stock availability
    $stmt = $pdo->prepare("SELECT stock FROM products WHERE product_id = ?");
    $stmt->execute([$productId]);
    $stock = $stmt->fetchColumn();

    if ($stock > 0) {   
        // Generate a unique barcode
        $barcode = uniqid('');
        
        $stmt = $pdo->prepare("INSERT INTO borrow_requests (student_id, product_id, due_date, status, barcode) VALUES (?, ?, ?, 'pending', ?)");
        $stmt->execute([$studentId, $productId, $dueDate, $barcode]);

        $stmt = $pdo->prepare("UPDATE products SET stock = stock - 1 WHERE product_id = ?");
        $stmt->execute([$productId]);

        $message = "Your borrow request for item ID $productId is pending admin approval. Barcode: $barcode";
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, student_id, message, is_read, created_at) VALUES (?, ?, ?, 0, NOW())");
        $stmt->execute([0, $studentId, $message]);

        echo json_encode(["status" => "success", "message" => "Borrow request sent successfully! Barcode: $barcode"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Item is out of stock!"]);
    }
    exit();
}
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrow Items - SIMS</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f7f6;
            color: #333;
            margin: 0;
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            position: fixed;
            height: 100vh;
            top: 0;
            left: 0;
            transition: transform 0.3s ease-in-out;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #1abc9c;
            font-size: 24px;
            padding-bottom: 15px;
            border-bottom: 2px solid #1abc9c;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            margin-bottom: 5px;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
        }
        .sidebar ul li a:hover {
            background-color: #1abc9c;
            transform: translateX(5px);
        }
        .sidebar ul li a.active {
            background-color: #1abc9c;
            color: white;
        }
        .sidebar ul li a i {
            margin-right: 10px;
            font-size: 18px;
        }
        .content {
            margin-left: 250px;
            padding: 30px;
            flex-grow: 1;
            transition: margin-left 0.3s ease-in-out;
        }
        .dashboard-header {
            background: #1abc9c;
            color: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 15px rgba(26,188,156,0.2);
        }
        .dashboard-header h2 {
            margin: 0;
            font-size: 2rem;
        }
        .search-bar {
            background: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            display: flex;
            gap: 15px;
            align-items: center;
        }
        .search-bar input {
            flex: 1;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.3s;
        }
        .search-bar input:focus {
            border-color: #1abc9c;
            outline: none;
            box-shadow: 0 0 0 3px rgba(26,188,156,0.1);
        }
        .search-bar select {
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            background: white;
            cursor: pointer;
            transition: all 0.3s;
        }
        .search-bar select:focus {
            border-color: #1abc9c;
            outline: none;
            box-shadow: 0 0 0 3px rgba(26,188,156,0.1);
        }
        .items-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        .item-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }
        .item-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .item-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .item-card h3 {
            margin: 0 0 10px 0;
            color: #2c3e50;
        }
        .item-card p {
            color: #666;
            margin: 5px 0;
        }
        .item-card .category-badge {
            position: absolute;
            top: 15px;
            right: 15px;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            background: #1abc9c;
            color: white;
        }
        .item-card .stock-badge {
            position: absolute;
            top: 15px;
            left: 15px;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            background: #3498db;
            color: white;
        }
        .item-card .borrow-btn {
            background: #1abc9c;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            width: 100%;
            margin-top: 15px;
            transition: all 0.3s;
        }
        .item-card .borrow-btn:hover {
            background: #16a085;
            transform: translateY(-2px);
        }
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>

<body>
    <nav class="sidebar">
        <h2>SIMS</h2>
        <ul>
            <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="borrow_items.php" class="active"><i class="fas fa-hand-holding"></i> Borrow Items</a></li>
            <li><a href="return_items.php"><i class="fas fa-undo"></i> Return Requests</a></li>
            <li><a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a></li>
            <li><a href="home.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </nav>

    <main class="content">
        <div class="dashboard-header">
            <h2>Borrow Items</h2>
        </div>

        <div class="search-bar">
            <input type="text" id="searchInput" placeholder="Search items...">
            <select id="categoryFilter">
                <option value="">All Categories</option>
                <option value="Input Devices">Input Devices</option>
                <option value="Output Devices">Output Devices</option>
                <option value="Storage Devices">Storage Devices</option>
                <option value="Networking">Networking</option>
                <option value="Accessories">Accessories</option>
            </select>
        </div>

        <div class="items-grid">
            <?php foreach ($availableProducts as $product): ?>
                <div class="item-card">
                    <span class="category-badge"><?php echo htmlspecialchars($product['category']); ?></span>
                    <span class="stock-badge">Stock: <?php echo htmlspecialchars($product['stock']); ?></span>
                    <?php if (!empty($product['image_url'])): ?>
                        <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="<?php echo htmlspecialchars($product['product_name']); ?>">
                    <?php else: ?>
                        <img src="uploads/no-image.png" alt="No image">
                    <?php endif; ?>
                    <h3><?php echo htmlspecialchars($product['product_name']); ?></h3>
                    <button class="borrow-btn" onclick="borrowItem(<?php echo $product['product_id']; ?>)">
                        <i class="fas fa-hand-holding"></i> Borrow Item
                    </button>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <!-- Rules and Regulations Modal -->
    <div id="rulesModal" class="modal">
        <div class="modal-content">
            <h2>Rules and Regulations</h2>
            <div class="rules-content">
                <ol>
                    <li>Items must be returned within 24 hours from the time of borrowing.</li>
                    <li>Late Return Penalties:
                        <ul>
                            <li>First day late: ₱25 fine</li>
                            <li>Each additional day: ₱50 per day</li>
                            <li>After 7 days: Item considered lost and full replacement cost will be charged</li>
                        </ul>
                    </li>
                    <li>Any damage or loss of items will be charged at full replacement cost.</li>
                    <li>Items must be returned in the same condition as they were borrowed.</li>
                    <li>Multiple late returns will result in borrowing privileges being suspended:
                        <ul>
                            <li>3 late returns: 1-week suspension</li>
                            <li>5 late returns: 1-month suspension</li>
                        </ul>
                    </li>
                    <li>Students must present their ID when collecting the borrowed item.</li>
                    <li>Borrowed items are for academic/school use only.</li>
                    <li>Report any issues with the item immediately upon discovery.</li>
                    <li>Fines must be paid before borrowing privileges can be restored.</li>
                </ol>
            </div>
            <div class="modal-buttons">
                <button id="disagreeBtn" class="modal-btn disagree">Disagree</button>
                <button id="agreeBtn" class="modal-btn agree">I Agree</button>
            </div>
        </div>
    </div>

    <style>
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1050;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .modal.show {
            display: block;
            opacity: 1;
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 30px;
            border-radius: 12px;
            width: 80%;
            max-width: 600px;
            position: relative;
            transform: translateY(-20px);
            transition: transform 0.3s ease;
        }

        .modal.show .modal-content {
            transform: translateY(0);
        }

        .modal h2 {
            color: #2c3e50;
            margin-bottom: 20px;
            text-align: center;
            font-size: 24px;
        }

        .rules-content {
            margin-bottom: 30px;
            max-height: 400px;
            overflow-y: auto;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 8px;
        }

        .rules-content ol {
            padding-left: 20px;
        }

        .rules-content li {
            margin-bottom: 15px;
            line-height: 1.5;
            color: #2c3e50;
        }

        .rules-content ul {
            list-style-type: disc;
            margin-left: 20px;
            margin-top: 10px;
        }

        .rules-content ul li {
            margin-bottom: 8px;
            color: #34495e;
        }

        .rules-content li strong {
            color: #e74c3c;
        }

        .modal-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 15px;
        }

        .modal-btn {
            padding: 10px 25px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s;
        }

        .modal-btn.agree {
            background-color: #1abc9c;
            color: white;
        }

        .modal-btn.agree:hover {
            background-color: #16a085;
        }

        .modal-btn.disagree {
            background-color: #e74c3c;
            color: white;
        }

        .modal-btn.disagree:hover {
            background-color: #c0392b;
        }
    </style>

    <script>
        let currentProductId = null;

        function showRulesModal(productId) {
            currentProductId = productId;
            const modal = document.getElementById('rulesModal');
            modal.classList.add('show');
        }

        function hideRulesModal() {
            const modal = document.getElementById('rulesModal');
            modal.classList.remove('show');
            currentProductId = null;
        }

        function borrowItem(productId) {
            showRulesModal(productId);
        }

        function proceedWithBorrowing() {
            if (!currentProductId) return;
            
            $.ajax({
                url: 'borrow_items.php',
                method: 'POST',
                data: {
                    borrow_item: true,
                    product_id: currentProductId
                },
                success: function(response) {
                    hideRulesModal();
                    const result = JSON.parse(response);
                    alert(result.message);
                    if (result.status === 'success') {
                        location.reload();
                    }
                },
                error: function() {
                    hideRulesModal();
                    alert('An error occurred. Please try again.');
                }
            });
        }

        // Event Listeners for Modal Buttons
        document.getElementById('agreeBtn').addEventListener('click', proceedWithBorrowing);
        document.getElementById('disagreeBtn').addEventListener('click', hideRulesModal);

        // Search functionality
        $('#searchInput').on('keyup', function() {
            const searchText = $(this).val().toLowerCase();
            $('.item-card').each(function() {
                const itemName = $(this).find('h3').text().toLowerCase();
                $(this).toggle(itemName.includes(searchText));
            });
        });

        // Category filter
        $('#categoryFilter').on('change', function() {
            const category = $(this).val();
            if (category === '') {
                $('.item-card').show();
            } else {
                $('.item-card').each(function() {
                    const itemCategory = $(this).find('.category-badge').text();
                    $(this).toggle(itemCategory === category);
                });
            }
        });
    </script>
</body>
</html>
