<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['is_admin'])) {
    die("Unauthorized access");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_id'])) {
    try {
        $requestId = $_POST['request_id'];
        $studentName = $_POST['student_name'];
        $productName = $_POST['product_name'];

        // Get student_id from the request
        $stmt = $pdo->prepare("SELECT student_id FROM borrow_requests WHERE request_id = ?");
        $stmt->execute([$requestId]);
        $studentId = $stmt->fetchColumn();

        if ($studentId) {
            // Set due date to 1 day from now
            $dueDate = date('Y-m-d', strtotime('+1 day'));

            // Update the request status and due date
            $stmt = $pdo->prepare("UPDATE borrow_requests SET status = 'approved', due_date = ? WHERE request_id = ?");
            $stmt->execute([$dueDate, $requestId]);

            // Send notification with due date
            $message = "Your borrow request for {$productName} has been approved. Due date: " . date('M d, Y', strtotime($dueDate));
            $stmt = $pdo->prepare("INSERT INTO notifications (user_id, student_id, message, is_read, created_at) VALUES (?, ?, ?, 0, NOW())");
            $stmt->execute([0, $studentId, $message]);

            echo "Request approved successfully!";
        } else {
            echo "Error: Student ID not found.";
        }
    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
    }
} else {
    echo "Invalid request.";
}
?>
