<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/api_error_response.php';
header('Content-Type: application/json');

// Get the token from the Authorization header
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;

if (!$token) {
    api_error_response('No token provided', 401);
}

try {
    $stmt = $pdo->prepare("SELECT id, is_admin FROM users WHERE token = :token AND is_admin = 1");
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        api_error_response('Invalid or expired token', 401, ['token' => $token]);
    }

    // Get all products with the requested fields
    $stmt = $pdo->prepare("
        SELECT 
            product_id,
            product_name,
            stock,
            category,
            image_url
        FROM products
        ORDER BY product_id DESC
    ");
    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "status" => "success",
        "data" => $products
    ]);
} catch (PDOException $e) {
    api_error_response('Database error: ' . $e->getMessage(), 500, ['query' => 'SELECT product_id, product_name, stock, category, image_url FROM products']);
}
?>