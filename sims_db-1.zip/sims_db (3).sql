-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2025 at 03:11 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sims_db`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ApproveReturn` (IN `p_request_id` INT)   BEGIN
    DECLARE v_product_id INT;

    -- Get the product_id from return_requests
    SELECT product_id INTO v_product_id FROM return_requests WHERE request_id = p_request_id;

    -- Update the status
    UPDATE return_requests SET status = 'approved' WHERE request_id = p_request_id;

    -- Increase the stock in products
    UPDATE products SET stock = stock + 1 WHERE product_id = v_product_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `RequestReturn` (IN `p_student_id` INT, IN `p_product_id` INT)   BEGIN
    INSERT INTO return_requests (student_id, product_id, status)
    VALUES (p_student_id, p_product_id, 'pending');
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `borrowed_products`
--

CREATE TABLE `borrowed_products` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `product_name` varchar(100) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `borrow_requests`
--

CREATE TABLE `borrow_requests` (
  `request_id` int(11) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `product_id` int(11) NOT NULL,
  `barcode` varchar(50) DEFAULT NULL,
  `due_date` date NOT NULL,
  `status` enum('pending','approved','rejected','returned') DEFAULT 'pending',
  `request_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `borrow_requests`
--

INSERT INTO `borrow_requests` (`request_id`, `student_id`, `product_id`, `barcode`, `due_date`, `status`, `request_date`) VALUES
(100, '2311600073', 144, 'barcode_682182679e8a6', '2025-05-13', 'returned', '2025-05-12 05:08:55'),
(101, '2311600073', 144, 'barcode_6824776f91ebc', '2025-05-15', 'returned', '2025-05-14 10:58:55'),
(102, '2311600073', 144, 'barcode_6824c715b7cde', '2025-05-15', 'returned', '2025-05-14 16:38:45'),
(103, '2311600073', 144, 'barcode_6824cc73d2c3c', '2025-05-15', 'returned', '2025-05-14 17:01:39'),
(115, '2311600073', 151, 'barcode_682caf94d74ec', '2025-05-22', 'returned', '2025-05-20 16:36:36'),
(116, '2311600073', 151, 'barcode_682cb03c0294c', '2025-05-21', 'returned', '2025-05-20 16:39:24'),
(120, '2311600073', 144, 'barcode_6830845c9c8e7', '2025-05-24', 'returned', '2025-05-23 14:21:16'),
(122, '2311600073', 162, '6832ddda94ab6', '2025-05-26', 'rejected', '2025-05-25 09:07:38'),
(123, '2311600073', 144, '6835067e82a47', '2025-05-28', 'returned', '2025-05-27 00:25:34'),
(124, '2311600073', 144, '683515bc44165', '2025-05-28', 'returned', '2025-05-27 01:30:36'),
(125, '2311600073', 144, '683a870664896', '2025-06-01', 'rejected', '2025-05-31 04:35:18'),
(126, '2311600073', 144, '683a881c020ed', '2025-06-01', 'rejected', '2025-05-31 04:39:56'),
(127, '2311600073', 144, '683a895f4f566', '2025-06-01', 'rejected', '2025-05-31 04:45:19'),
(128, '2311600073', 144, '683a8a4f66349', '2025-06-01', 'rejected', '2025-05-31 04:49:19'),
(129, '2311600073', 144, '683a8af5c7588', '2025-06-01', 'rejected', '2025-05-31 04:52:05'),
(130, '2311600073', 144, '683a8ecb5a9e5', '2025-06-01', 'returned', '2025-05-31 05:08:27'),
(131, '2311600073', 144, '683a8ee33b50b', '2025-06-01', 'returned', '2025-05-31 05:08:51'),
(132, '2311600073', 144, '683cf46d8a1f7', '2025-06-03', 'returned', '2025-06-02 00:46:37'),
(133, '2311600073', 144, '683cf51cad5b6', '2025-06-03', 'returned', '2025-06-02 00:49:32'),
(134, '2311600073', 144, '683cf9ca95083', '2025-06-03', 'returned', '2025-06-02 01:09:30');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_items`
--

CREATE TABLE `inventory_items` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `category` varchar(50) DEFAULT NULL,
  `item_condition` varchar(50) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `image_url` varchar(255) DEFAULT NULL,
  `added_by` int(11) DEFAULT NULL,
  `student_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory_items`
--

INSERT INTO `inventory_items` (`id`, `name`, `description`, `quantity`, `created_at`, `category`, `item_condition`, `status`, `image_url`, `added_by`, `student_id`) VALUES
(28, 'UTP cable', 'mawawala kasi sa bahay eh', 1, '2025-05-25 08:48:09', 'Networking', 'New', 'rejected', '', NULL, NULL),
(35, 'UTP cable', '123', 0, '2025-05-27 01:50:09', 'Input Devices', 'New', 'approved', '', NULL, '2311600073'),
(36, 'UTP cable', '123', 0, '2025-05-27 14:07:52', 'Input Devices', 'New', 'approved', '', NULL, '2311600073'),
(37, 'maca', '123', 0, '2025-05-27 14:09:33', 'Input Devices', 'Like New', 'approved', '', NULL, '2311600073');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `student_id` varchar(20) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `student_id`, `message`, `is_read`, `created_at`) VALUES
(60, 0, NULL, 'Inventory item (\'maca\') has been approved and is now available.', 0, '2025-05-17 07:10:53'),
(65, 0, NULL, 'A new inventory item (\'qwe\') has been submitted and is pending approval.', 0, '2025-05-20 11:15:47'),
(66, 0, NULL, 'A new inventory item (\'123\') has been submitted and is pending approval.', 0, '2025-05-20 11:16:05'),
(67, 0, NULL, 'A new inventory item (\'123\') has been submitted and is pending approval.', 0, '2025-05-20 11:17:17'),
(68, 0, NULL, 'Inventory item (\'qwe\') has been approved and is now available.', 0, '2025-05-20 11:17:28'),
(69, 0, NULL, 'A new inventory item (\'qwe\') has been submitted and is pending approval.', 0, '2025-05-20 11:17:38'),
(70, 0, NULL, 'Inventory item (\'qwe\') has been approved and is now available.', 0, '2025-05-20 11:17:47'),
(71, 0, NULL, 'A new inventory item (\'1\') has been submitted and is pending approval.', 0, '2025-05-20 11:19:02'),
(72, 0, NULL, 'Inventory item (\'1\') has been approved and is now available.', 0, '2025-05-20 11:19:09'),
(73, 0, NULL, 'A new inventory item (\'1\') has been submitted and is pending approval.', 0, '2025-05-20 11:19:41'),
(74, 0, NULL, 'Inventory item (\'1\') has been approved and is now available.', 0, '2025-05-20 11:19:53'),
(94, 0, NULL, 'Inventory item (\'123\') has been approved and is now available.', 0, '2025-05-20 16:36:49'),
(95, 0, NULL, 'Inventory item (\'123\') has been approved and is now available.', 0, '2025-05-20 16:37:02'),
(96, 0, NULL, 'Inventory item (\'123\') has been approved and is now available.', 0, '2025-05-20 16:37:11'),
(121, 0, NULL, 'A new inventory item (\'UTP cable\') has been submitted and is pending approval.', 0, '2025-05-25 08:48:09'),
(122, 0, NULL, 'A new inventory item (\'UTP cable\') has been submitted and is pending approval.', 0, '2025-05-25 08:55:17'),
(123, 0, NULL, 'Inventory item (\'UTP cable\') has been approved and is now available.', 0, '2025-05-25 08:55:25'),
(124, 0, NULL, 'New retrieval request for item \'UTP cable\' needs approval.', 0, '2025-05-25 08:57:29'),
(125, 13, NULL, 'Your retrieval request for item \'UTP cable\' has been rejected.', 0, '2025-05-25 08:57:36'),
(126, 0, NULL, 'New retrieval request for item \'UTP cable\' needs approval.', 0, '2025-05-25 08:57:44'),
(127, 13, NULL, 'Your retrieval request for item \'UTP cable\' has been approved.', 0, '2025-05-25 08:58:05'),
(136, 0, NULL, 'A new inventory item (\'UTP cable\') has been submitted and is pending approval.', 0, '2025-05-27 00:26:14'),
(139, 0, NULL, 'Inventory item (\'UTP cable\') has been approved and is now available.', 0, '2025-05-27 00:33:28'),
(140, 0, NULL, 'New retrieval request for item \'UTP cable\' needs approval.', 0, '2025-05-27 00:33:39'),
(141, 0, NULL, 'New retrieval request for item \'UTP cable\' needs approval.', 0, '2025-05-27 00:45:47'),
(145, 0, NULL, 'A new inventory item (\'test\') has been submitted and is pending approval.', 0, '2025-05-27 01:43:44'),
(146, 0, NULL, 'Inventory item (\'test\') has been approved and is now available.', 0, '2025-05-27 01:43:51'),
(147, 0, NULL, 'New retrieval request for item \'test\' needs approval.', 0, '2025-05-27 01:45:27'),
(148, 0, NULL, 'A new inventory item (\'UTP cable\') has been submitted and is pending approval.', 0, '2025-05-27 01:46:52'),
(149, 0, NULL, 'A new inventory item (\'123123\') has been submitted and is pending approval.', 0, '2025-05-27 01:48:23'),
(150, 0, NULL, 'A new inventory item (\'UTP cable\') has been submitted and is pending approval.', 0, '2025-05-27 01:50:09'),
(151, 0, NULL, 'Inventory item (\'UTP cable\') has been approved and is now available.', 0, '2025-05-27 01:52:00'),
(152, 0, NULL, 'New retrieval request for item \'UTP cable\' needs approval.', 0, '2025-05-27 01:52:12'),
(155, 0, NULL, 'A new inventory item (\'UTP cable\') has been submitted and is pending approval.', 0, '2025-05-27 14:07:52'),
(156, 0, NULL, 'A new inventory item (\'maca\') has been submitted and is pending approval.', 0, '2025-05-27 14:09:33'),
(157, 0, NULL, 'Inventory item (\'maca\') has been approved and is now available.', 0, '2025-05-27 14:09:47'),
(158, 0, NULL, 'New retrieval request submitted by Unknown Student for item \'maca\'. Reason: 23', 0, '2025-05-27 14:10:03'),
(161, 0, NULL, 'New retrieval request submitted by Unknown Student for item \'maca\'. Reason: 213', 0, '2025-05-27 14:11:12'),
(164, 0, NULL, 'Inventory item (\'Unknown Item\') has been approved and is now available.', 0, '2025-05-27 14:49:10'),
(165, 0, NULL, 'Inventory item (\'Unknown Item\') has been approved and is now available.', 0, '2025-05-27 14:49:23'),
(166, 0, NULL, 'Inventory item (\'Unknown Item\') has been approved and is now available.', 0, '2025-05-27 14:51:48'),
(167, 0, NULL, 'Inventory item (\'Unknown Item\') has been approved and is now available.', 0, '2025-05-27 14:52:24'),
(168, 0, NULL, 'Inventory item (\'UTP cable\') has been approved and is now available.', 0, '2025-05-27 14:52:50'),
(169, 0, NULL, 'New retrieval request submitted by Unknown Student for item \'UTP cable\'. Reason: qweqwe', 0, '2025-05-27 14:56:41'),
(170, NULL, '2311600089', 'Your retrieval request for item \'UTP cable\' is now pending for approval.\nReason: qweqwe', 0, '2025-05-27 14:56:41'),
(171, 0, '2311600089', 'Your retrieval request for item \'UTP cable\' has been approved.', 0, '2025-05-27 14:57:02'),
(172, 0, NULL, 'New retrieval request submitted by Unknown Student for item \'UTP cable\'. Reason: sdf', 0, '2025-05-27 14:58:50'),
(193, 0, '2311600073', 'Your borrow request for item ID 144 is pending admin approval. Barcode: 683cf46d8a1f7', 0, '2025-06-02 00:46:37'),
(194, 0, '2311600073', 'Your borrow request for test has been approved. Due date: Jun 03, 2025', 0, '2025-06-02 00:46:42'),
(195, 0, '2311600073', 'Your return request for test has been approved.', 0, '2025-06-02 00:47:19'),
(196, 0, '2311600073', 'Your borrow request for item ID 144 is pending admin approval. Barcode: 683cf51cad5b6', 0, '2025-06-02 00:49:32'),
(197, 0, '2311600073', 'Your borrow request for test has been approved. Due date: Jun 03, 2025', 0, '2025-06-02 00:49:45'),
(198, 0, '2311600073', 'Your return request for test has been rejected.', 0, '2025-06-02 00:49:56'),
(199, 0, '2311600073', 'Your return request for test has been approved.', 0, '2025-06-02 00:50:08'),
(200, 0, '2311600073', 'Your borrow request for item ID 144 is pending admin approval. Barcode: 683cf9ca95083', 0, '2025-06-02 01:09:30'),
(201, 0, '2311600073', 'Your borrow request for test has been approved. Due date: Jun 03, 2025', 0, '2025-06-02 01:09:40');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `stock` int(11) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `stock`, `category`, `image_url`) VALUES
(135, 'Razer DeathAdder V3 Pro (Mouse)', 4, 'Input Devices', 'uploads/th (6).jpg'),
(142, 'Keychron C1 (Keyboard)', 3, 'Input Devices', 'uploads/th (2).jpg'),
(143, 'AVID AE-54 (Headphones)', 5, 'Input Devices', 'uploads/th (3).jpg'),
(144, 'test', 48, 'Output Devices', 'uploads/Screenshot 2025-05-03 170302.png'),
(152, 'Fujitsu (Laptop)', 10, 'Input Devices', 'uploads/th (5).jpg'),
(159, 'HP/Dell (Laptop)', 10, 'Input Devices', 'uploads/212.jpg'),
(160, 'Network RJ45 Cat5 Cat6 Punch Down Network UTP Cable Cutter Stripper', 15, 'Input Devices', 'uploads/RJ45 Cat5 Punch Down Network UTP Cable Cutter Stripper-1024x768_0.jpg'),
(161, 'Iwiss Pin Crimping Tools', 10, 'Input Devices', 'uploads/Best-crimping-tools-5.jpg'),
(162, 'Fundamental in Information of Technnology', 3, 'Output Devices', 'uploads/9788182092457.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `retrieval_requests`
--

CREATE TABLE `retrieval_requests` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `reason` text DEFAULT NULL,
  `preferred_date` date DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `retrieval_requests`
--

INSERT INTO `retrieval_requests` (`id`, `item_id`, `student_id`, `reason`, `preferred_date`, `status`, `created_at`) VALUES
(1, 30, '2311600073', '213', '2025-05-27', 'approved', '2025-05-27 00:45:47'),
(3, 35, '2311600073', '213', '2025-05-27', 'approved', '2025-05-27 01:52:12'),
(4, 37, '2311600073', '23', '2025-05-27', 'approved', '2025-05-27 14:10:03'),
(5, 37, '2311600073', '213', '2025-05-27', 'approved', '2025-05-27 14:11:12'),
(6, 36, '2311600089', 'qweqwe', '2025-05-27', 'approved', '2025-05-27 14:56:41'),
(7, 36, '2311600073', 'sdf', '2025-05-27', 'approved', '2025-05-27 14:58:50');

-- --------------------------------------------------------

--
-- Table structure for table `return_requests`
--

CREATE TABLE `return_requests` (
  `request_id` int(11) NOT NULL,
  `student_id` varchar(50) NOT NULL,
  `product_id` int(11) NOT NULL,
  `request_date` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `barcode` text DEFAULT NULL,
  `processed_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `return_requests`
--

INSERT INTO `return_requests` (`request_id`, `student_id`, `product_id`, `request_date`, `status`, `barcode`, `processed_date`) VALUES
(9, '2311600073', 144, '2025-05-12 12:53:50', '', NULL, NULL),
(10, '2311600073', 144, '2025-05-12 13:00:29', 'approved', NULL, NULL),
(11, '2311600073', 144, '2025-05-12 13:03:38', 'approved', NULL, NULL),
(12, '2311600073', 135, '2025-05-12 13:06:44', 'approved', NULL, NULL),
(13, '2311600073', 144, '2025-05-12 13:09:16', 'approved', NULL, NULL),
(14, '2311600073', 144, '2025-05-15 00:59:27', 'approved', NULL, NULL),
(15, '2311600073', 144, '2025-05-15 01:00:22', 'approved', NULL, NULL),
(16, '2311600073', 144, '2025-05-15 01:00:58', 'approved', NULL, NULL),
(17, '2311600073', 144, '2025-05-15 01:01:55', 'approved', NULL, NULL),
(18, '2311600073', 144, '2025-05-15 01:35:06', 'approved', NULL, NULL),
(19, '2311600073', 144, '2025-05-20 19:20:06', 'approved', NULL, NULL),
(20, '2311600073', 144, '2025-05-20 19:21:56', 'approved', NULL, NULL),
(21, '2311600073', 144, '2025-05-20 19:22:58', 'approved', NULL, NULL),
(22, '2311600073', 144, '2025-05-20 19:24:24', 'approved', NULL, NULL),
(23, '2311600073', 144, '2025-05-20 19:25:01', 'approved', NULL, NULL),
(24, '2311600073', 144, '2025-05-20 19:27:05', 'approved', NULL, NULL),
(25, '2311600073', 151, '2025-05-21 00:46:12', 'approved', NULL, NULL),
(26, '2311600073', 151, '2025-05-23 22:09:32', 'rejected', NULL, NULL),
(27, '2311600073', 151, '2025-05-23 22:10:29', 'rejected', NULL, NULL),
(28, '2311600073', 151, '2025-05-23 22:10:39', 'rejected', NULL, NULL),
(29, '2311600073', 151, '2025-05-23 22:12:03', 'rejected', NULL, NULL),
(31, '2311600073', 144, '2025-05-23 22:16:46', 'approved', NULL, NULL),
(32, '2311600073', 151, '2025-05-23 22:16:56', 'approved', NULL, NULL),
(36, '2311600073', 144, '2025-05-23 22:22:06', 'approved', NULL, NULL),
(37, '2311600073', 162, '2025-05-25 17:09:01', 'rejected', NULL, NULL),
(38, '2311600073', 162, '2025-05-25 17:11:09', 'rejected', NULL, NULL),
(39, '2311600073', 162, '2025-05-25 17:11:21', 'approved', NULL, NULL),
(40, '2311600073', 144, '2025-05-27 08:31:37', 'approved', NULL, NULL),
(41, '2311600073', 144, '2025-05-31 13:04:41', 'approved', NULL, NULL),
(43, '2311600073', 144, '2025-05-31 13:11:50', 'approved', NULL, NULL),
(44, '2311600073', 144, '2025-06-02 08:46:48', 'approved', 'jwakjdlakqeq', NULL),
(45, '2311600073', 144, '2025-06-02 08:49:50', 'rejected', NULL, NULL),
(46, '2311600073', 144, '2025-06-02 08:50:04', 'approved', NULL, NULL),
(47, '2311600073', 144, '2025-06-02 09:09:50', 'pending', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `student_id` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_admin` tinyint(1) DEFAULT 0,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `profile_pic` varchar(255) DEFAULT 'default.jpg',
  `approved` tinyint(1) DEFAULT 0,
  `token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `student_id`, `password`, `name`, `email`, `created_at`, `is_admin`, `role`, `profile_pic`, `approved`, `token`) VALUES
(13, '2311600073', '$2y$10$xyPLAXXiaNhHs4yqRDepSuX9aQFInk4byKAap4A41k6vEg7XZiYb2', 'Jerald ', 'geraldmacafernandez@gmail.com', '2025-02-21 10:06:49', 0, 'user', 'uploads/67bcfaae8bdb5_download.jpg.jfif', 1, NULL),
(21, '2311600083', '$2y$10$Yh1l56zMYzP8BKzEWKIpVO5M/ZTBAumw9q6XYoy1.fBJC1BP/fVty', 'JeraldAdmin', 'jealdfern099@gmail.com', '2025-02-24 03:44:24', 1, 'admin', 'default.jpg', 0, 'eadaa99bd4fbc98a6743c5449989ae8f'),
(22, '2311600099', '$2y$10$DxA9vxeVh8o2G9ovJYV5JuHvojjMQptn4KumclmSb.eyo4xAXPGZW', 'MACA', 'JERALD@gmail.com', '2025-04-05 05:28:56', 0, 'user', 'default.jpg', 1, NULL),
(24, '2311600089', '$2y$10$dnxSFW2sdqgPuzdmPpKuJudO.hA1pPsJGQUn2ccvfYvEqyHf0EK5.', 'xyzl racaza', 'xyzl@email.com', '2025-05-20 14:44:13', 0, 'user', 'default.jpg', 1, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `borrowed_products`
--
ALTER TABLE `borrowed_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`student_id`);

--
-- Indexes for table `borrow_requests`
--
ALTER TABLE `borrow_requests`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `users` (`student_id`),
  ADD KEY `products` (`product_id`);

--
-- Indexes for table `inventory_items`
--
ALTER TABLE `inventory_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `retrieval_requests`
--
ALTER TABLE `retrieval_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `return_requests`
--
ALTER TABLE `return_requests`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_id` (`student_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_id` (`student_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `student_id_2` (`student_id`),
  ADD UNIQUE KEY `student_id_3` (`student_id`),
  ADD UNIQUE KEY `student_id_4` (`student_id`),
  ADD UNIQUE KEY `student_id_5` (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `borrowed_products`
--
ALTER TABLE `borrowed_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `borrow_requests`
--
ALTER TABLE `borrow_requests`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT for table `inventory_items`
--
ALTER TABLE `inventory_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=202;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=186;

--
-- AUTO_INCREMENT for table `retrieval_requests`
--
ALTER TABLE `retrieval_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `return_requests`
--
ALTER TABLE `return_requests`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `borrowed_products`
--
ALTER TABLE `borrowed_products`
  ADD CONSTRAINT `borrowed_products_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`student_id`) ON DELETE CASCADE;

--
-- Constraints for table `retrieval_requests`
--
ALTER TABLE `retrieval_requests`
  ADD CONSTRAINT `retrieval_requests_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `inventory_items` (`id`),
  ADD CONSTRAINT `retrieval_requests_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `users` (`student_id`);

--
-- Constraints for table `return_requests`
--
ALTER TABLE `return_requests`
  ADD CONSTRAINT `return_requests_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`student_id`),
  ADD CONSTRAINT `return_requests_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
